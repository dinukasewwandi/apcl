<?php
/*
 * Template Name: Resources
 
 */
?>
<?php
 get_header();

  ?>


  <!-- banner start -->
   
    <div class="banner-img " style="  background-image: url('<?php echo get_template_directory_uri(); ?>/./inc/img/resources_1320x350.jpg');">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
               <!-- <img src="./inc/img/slider2.jpg" alt=""> -->
            </div>
        </div>
       
    </div>
 
  <!-- banner end -->
  
  
    <!-- Body Content Start-->

    <div class="body-content  pt-3 ">

        <div class="container">
            <div class="row">

                <div class="col-12">
                    

                    <!-- design category Start -->
                    <div class="design-categories">
                        <section class="service-design">
                            <div class="container-fluid">


                                <!-- Research Projects -->
                                <div class="row research-row  ">


                                    <div class="heading-body">
                                        <div class="row ">
                                            <div class="col-lg-6 col-md-6 col-sm-12">
                                                <div class="image mt-4">
                                                    <img width="1024" height="1024" src="<?php echo get_template_directory_uri(); ?>/./inc/img/Resource/resorce.jpg" alt=""
                                                        loading="lazy">
                                                </div>
                                            </div>

                                            <div class="col-lg-6 col-md-6 col-sm-12">
                                                <div class="design-text-content">
                                                    <h3 class="my-4">Research Projects​</h3>

                                                    <p class="design-para">Discover the research projects of APCL employees as well as outside engineers supervised by Eng. D. G. Rienzie Fernando (Managing Director).</p>


                                                    <!-- Button trigger modal -->
                                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" class="design-btn"
                                                        data-bs-target="#modal1">
                                                        More info...!
                                                    </button>


                                                    

                                                    <!-- Modal -->
                                                    <div class="modal fade" id="modal1" data-bs-backdrop="static"
                                                        data-bs-keyboard="false" tabindex="-1"
                                                        aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                        <div class="modal-dialog modal-dialog-scrollable modal-lg">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title " id="staticBackdropLabel ">
                                                                        Research Projects</h5>

                                                                        
                                                                    <button type="button" class="btn-close"
                                                                        data-bs-dismiss="modal"
                                                                        aria-label="Close"></button>
                                                                </div>
                                                                <div class="modal-body resource-modal">
                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                                <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                              </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                          <a href="http://opac.lib.uom.lk/cgi-bin/koha/opac-detail.pl?biblionumber=19577&query_desc=au%2Cwrdl%3A%20rienzie"><p class="respara">Analysis of surface flash over of 33 kV insulator due to saline pollution [2010]</p></a>  
                                                                          <p id="respara-ref1">by Janaka, N.H.C | Prof. J.R Lucas [supervisor] | Eng. Rienzie Fernando [supervisor].
                                                                        </p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                                <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                              </svg></i>
                                                                        </div>

                                                                        <div class="col-9">
                                                                          <a href="http://opac.lib.uom.lk/cgi-bin/koha/opac-detail.pl?biblionumber=19523&query_desc=au%2Cwrdl%3A%20rienzie">  <p class="respara">A Conceptual design for a tower type concentrating solar power plant near Hambantota [2010] </p></a>
                                                                          <p id="respara-ref2">by Wijayawardhana N.A.B.R | Eng. WDAS Wijayapala ; Eng. DG Rienzie Fernando [supervisor].
                                                                        </p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                                <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                              </svg></i>
                                                                        </div>

                                                                        <div class="col-9">
                                                                          <a href="http://opac.lib.uom.lk/cgi-bin/koha/opac-detail.pl?biblionumber=18827&query_desc=au%2Cwrdl%3A%20rienzie"><p class="respara">Neutral current mitigation in low voltage installations [2010]</p></a>  
                                                                          <p id="respara-ref3">by Ameer, M.I.S | Eng. Rienzie Fernando [supervisor] | Eng. Upuli Jayatunga [supervisor].
                                                                        </p>
                                                                        </div>
                                                                        <div class="col-1"></div>

                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                                <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                              </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                           <a href="http://opac.lib.uom.lk/cgi-bin/koha/opac-detail.pl?biblionumber=19532&query_desc=au%2Cwrdl%3A%20rienzie"><p class="respara">Probabilistic approach to fix the overhead line power transfer limits, with effective wind cooling [2010]</p></a> 
                                                                           <p id="respara-ref4">by Kumara, D.M.J.R | Eng. W.D.A.S. Wijayapala [supervisor] | Eng. D.G. Rienzie Fernando [supervisor].
                                                                        </p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                             <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                                <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                              </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                          <a href="http://opac.lib.uom.lk/cgi-bin/koha/opac-detail.pl?biblionumber=176271&query_desc=au%2Cwrdl%3A%20rienzie"> <p class="respara">Development of a generalized methodology for blackout restoration : a case study of Sri Lankan power system [2018]</p></a>
                                                                          <p id="respara-ref5">by Sirisena, Katugampalage Laksith Uchitha | Dr. W.D. Prasad [supervisor] | Eng. Rienzie Fernando [supervisor].
                                                                        </p> 
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                             <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                                <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                              </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                           <a href="http://opac.lib.uom.lk/cgi-bin/koha/opac-detail.pl?biblionumber=177103&query_desc=au%2Cwrdl%3A%20rienzie"><p class="respara">Study of the settings of over speed protection for enhancing frequency stability : a case study for Lakvijaya power station [2019]</p></a> 
                                                                           <p id="respara-ref6">By: Lakmewan, Karunanayakage Janaka | Dr. W.D. Prasad [supervisor] | Eng. Rienzie Fernando
                                                                        </p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                        

                                                                    


                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-info"
                                                                        data-bs-dismiss="modal">Close</button>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>



                                                </div>








                                            </div>
                                        </div>
                                    </div>
                                </div>
                                   <!-- Research Projects end -->


   
   
                                   <!-- Downloads -->
                                <div class="row  ">

                                    <div class="heading-body1">
                                        <div class="row revers-row flex-sm-row">
                                            <div class="col-lg-6 col-md-6 col-sm-12">
                                                <div class="design-text-content1">
                                                    <h3 class="my-4">Downloads</h3>

                                              

                                                    <!-- Button trigger modal -->
                                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                                        data-bs-target="#modal2">
                                                        More info...!
                                                    </button>

                                                    <!-- Modal -->
                                                    <div class="modal fade" id="modal2" data-bs-backdrop="static"
                                                        data-bs-keyboard="false" tabindex="-1"
                                                        aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                        <div class="modal-dialog modal-dialog-scrollable modal-lg">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title " id="staticBackdropLabel ">
                                                                        Transmission Line Designs</h5>
                                                                    <button type="button" class="btn-close"
                                                                        data-bs-dismiss="modal"
                                                                        aria-label="Close"></button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                             <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                                <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                              </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>We will upload useful materials in near future. Stay tuned !</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                               

                                                                  

                                                        


                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-info"
                                                                        data-bs-dismiss="modal">Close</button>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>






                                                </div>







                                            </div>

                                            <div class="col-lg-6 col-md-6 col-sm-12">
                                                <div class="image1 mt-4">
                                                    <img width="1024" height="1024" src="<?php echo get_template_directory_uri(); ?>/./inc/img/Resource/download.jpg" alt=""
                                                        loading="lazy">
                                                </div>


                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Downloads end -->







                            </div>
                    </div>
                </div>



            </div>
            </section>
        </div>
        <!-- design category end -->
    </div>


    </div>
    </div>
    </div>
    <!-- Body Content End-->
  
  <?php
get_footer();
  ?>
