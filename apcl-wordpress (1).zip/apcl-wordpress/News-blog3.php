<?php
/*
 * Template Name: News-Blog3
 
 */
?>
<?php
 get_header();

  ?>

 <!-- banner start -->
   
    <div class="banner-img " style="  background-image: url('<?php echo get_template_directory_uri(); ?>/./inc/img/banners-img/news-banner.png');">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
               <!-- <img src="./inc/img/slider2.jpg" alt=""> -->
            </div>
        </div>
       
    </div>
 
  <!-- banner end -->

      <!-- Body Content Start-->

      <div class="body-content  pt-3 ">

<div class="container">
    <div class="row">

        <div class="col-12">
            <div class="section" id="NewsPage">

                <div class="section-header text-center ">
                    <p class="h1 fw-bolder">BLOGS</p>


                </div>

                <!-- news section start -->
                <div class="container">
                    <div class="row latest-news mt-5">


                        <div class="col-lg-12 col-md-12   latest-news-col ">


                            <div class="main-row">
                                <div class="col-lg-12 col-md-12 col-sm-12">

                                    <!-- category column start -->
                                    <div class="row primary-blog">
                                        <div class="col-lg-3 col-md-12 col-sm-12 catogories-sidebar">

                                            <!-- about us row start -->
                                            <div class="aboutUs-section">

                                                <div class="row aboutUs-header ">
                                                    <p class="h6 text-capitalize fw-bolder about mb-3">ABOUT US
                                                    </p>
                                                </div>

                                                <div class="row aboutUs-para">
                                                    Lorem ipsum dolor sit amet consectetur adipisicing elit.
                                                    Dolor
                                                    tenetur
                                                    eaque
                                                    ipsum veritatis fugiat amet eius dolores inventore dicta
                                                    similique quo
                                                    saepe
                                                    doloremque, molestias quod aut nesciunt deserunt eligendi
                                                    nemo.
                                                </div>
                                            </div>
                                            <!-- about us row end -->



                                            <!-- categories row start -->
                                            <div class="category-list-section">
                                                <div class="row category-list-header mt-5">
                                                    <div class="h6 text-capitalize fw-bolder about">CATEGORIES
                                                    </div>

                                                </div>

                                                <div class="row category-list">
                                                    <ul class="removebullets">
                                                        <li>
                                                            <a href="">Business
                                                                <span><svg xmlns="http://www.w3.org/2000/svg"
                                                                        width="12" height="12" fill="#cccccc"
                                                                        class="bi bi-chevron-right"
                                                                        viewBox="0 0 16 16">
                                                                        <path fill-rule="evenodd"
                                                                            d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z" />
                                                                    </svg></span>
                                                            </a>
                                                        </li>

                                                        <li>
                                                            <a href="">Health
                                                                <span><svg xmlns="http://www.w3.org/2000/svg"
                                                                        width="12" height="12" fill="#cccccc"
                                                                        class="bi bi-chevron-right"
                                                                        viewBox="0 0 16 16">
                                                                        <path fill-rule="evenodd"
                                                                            d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z" />
                                                                    </svg></span>
                                                            </a>
                                                        </li>

                                                        <li>
                                                            <a href="">Lifestyle
                                                                <span><svg xmlns="http://www.w3.org/2000/svg"
                                                                        width="12" height="12" fill="#cccccc"
                                                                        class="bi bi-chevron-right"
                                                                        viewBox="0 0 16 16">
                                                                        <path fill-rule="evenodd"
                                                                            d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z" />
                                                                    </svg></span>
                                                            </a>
                                                        </li>

                                                        <li>
                                                            <a href="">News
                                                                <span><span><svg
                                                                            xmlns="http://www.w3.org/2000/svg"
                                                                            width="12" height="12"
                                                                            fill="#cccccc"
                                                                            class="bi bi-chevron-right"
                                                                            viewBox="0 0 16 16">
                                                                            <path fill-rule="evenodd"
                                                                                d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z" />
                                                                        </svg></span>
                                                            </a>
                                                        </li>

                                                        <li>
                                                            <a href="">Sports
                                                                <span><span><svg
                                                                            xmlns="http://www.w3.org/2000/svg"
                                                                            width="12" height="12"
                                                                            fill="#cccccc"
                                                                            class="bi bi-chevron-right"
                                                                            viewBox="0 0 16 16">
                                                                            <path fill-rule="evenodd"
                                                                                d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z" />
                                                                        </svg></span>
                                                            </a>
                                                        </li>

                                                        <li>
                                                            <a href="">Travel
                                                                <span> <span><span><svg
                                                                                xmlns="http://www.w3.org/2000/svg"
                                                                                width="12" height="12"
                                                                                fill="#cccccc"
                                                                                class="bi bi-chevron-right"
                                                                                viewBox="0 0 16 16">
                                                                                <path fill-rule="evenodd"
                                                                                    d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z" />
                                                                            </svg></span>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                </div>
                                                <!-- categories row end -->
                                            </div>


                                            <!-- Latest products row start -->
                                            <div class="latest-products-section">
                                                <div class="row products-list-header mt-5 mb-3">
                                                    <div class="h6 text-capitalize fw-bolder products">LATEST
                                                        PRODUCTS</div>

                                                </div>

                                                <div class="ptoduct-list-imgs">
                                                    <div class="row product-img-row">
                                                        <div class="product-img-col col-4">
                                                            <img src="<?php echo get_template_directory_uri(); ?>/./inc/img/news-img/news1.jpg" alt="">
                                                        </div>
                                                        <div class="product-img-col col-4">
                                                            <img src="<?php echo get_template_directory_uri(); ?>/./inc/img/news-img/news2.jpg" alt="">
                                                        </div>
                                                        <div class="product-img-col col-4">
                                                            <img src="<?php echo get_template_directory_uri(); ?>/./inc/img/news-img/news3.jpg" alt="">
                                                        </div>

                                                    </div>

                                                    <div class="row product-img-row mt-2">
                                                        <div class="product-img-col col-4">
                                                            <img src="<?php echo get_template_directory_uri(); ?>/./inc/img/news-img/news4.jpg" alt="">
                                                        </div>
                                                        <div class="product-img-col col-4">
                                                            <img src="<?php echo get_template_directory_uri(); ?>/./inc/img/news-img/news5.jpg" alt="">
                                                        </div>
                                                        <div class="product-img-col col-4">
                                                            <img src="<?php echo get_template_directory_uri(); ?>/./inc/img/news-img/news6.jpg" alt="">
                                                        </div>

                                                    </div>
                                                </div>

                                            </div>
                                            <!-- Latest products row end -->

                                        </div>
                                        <!-- category column end -->








                                        <!-- news column start -->

                                        <div class="col-lg-9 col-md-12 col-sm-12 news-details-bar ">



                                            <!-- Primary injection row start -->
                                            <div class="Trends-section ">
                                                <div class="row ">
                                                    <div class="col-lg-12 col-md-12 col-sm-12 text-center  main-content ">
                                                        <img class="blog-img"
                                                            src="<?php echo get_template_directory_uri(); ?>/./inc/img/news-img/819x462 3.jpg" alt="">

                                                        <div class="news-blog-details">

                                                            <div class="row Trends-header  mt-4 fw-bold ">
                                                                <p class=" text-capitalize text-start  about mt-3 "
                                                                    align="left">Primary Injection Testing</p>
                                                            </div>

                                                            <div class=" date-time mb-4">
                                                                <ul class="non-bullets">
                                                                    <li>December 11, 2014</li>

                                                                    <li>No Comments</li>
                                                                    <li>Sports , Travel</li>
                                                                </ul>
                                                            </div>


                                                            <div class="row Trends-para text-start">


                                                                We are delighted to announce that APCL’s Quality Management System (QMS) has been recognized as compliant with ISO 9001 : 2015 by DAS Certification Body (accredited by United Kingdom Accreditation Service).
                                                                <br> <br>

                                                                With streamlined procedures, we intend to provide highest Quality & hassle-free outputs to our customers as a consulting organization which maintained its quality services since 2004. <br> <br>

                                                                APCL extends its gratitude to DAS Certification body, ISO consultant and especially APCL team including CEO, EM, HoDs & Engineers who made it possible and remembering previous engineers who contributed throughout !
                                                                <br> <br>

                                     

                                                            </div>
                                                        </div>



                                                    </div>





                                                </div>

                                            </div>
                                            <!--  Primary injection row end -->

                                          








                                            <!-- news column end -->
                                        </div>
                                    </div>

                                </div>

                            </div>
                        </div>



                    </div>
                    <!-- news section end -->
                </div>



            </div>
        </div>
    </div>
</div>
</div>
<!-- Body Content End-->

<?php
get_footer();
  ?>
  