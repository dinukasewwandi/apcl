<?php
/*
 * Template Name: Services
 
 */
?>
<?php
 get_header();

  ?>

 
  <!-- banner start -->
   
    <div class="banner-img " style="  background-image: url('<?php echo get_template_directory_uri(); ?>/./inc/img/banners-img/services-banner.png');">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
               <!-- <img src="./inc/img/slider2.jpg" alt=""> -->
            </div>
        </div>
       
    </div>
 
  <!-- banner end -->
   <!-- body content Start -->

    <!-- design category Start -->
    <div class="service-categories">
        <section class="service design">
            <div class="container-fluid">
                <div class="row">
                    <div class="heading-content">
                        <h6 class="heading-title">SERVICES</h5>
                            <h5 class="heading-subtitle">
                                Design
                            </h5>

                            <p class="heading-des">
                                We specialize in providing high quality design and consultancy services in all fields
                                concerning Electrical Power Engineering and Building Services Engineering. As an
                                experienced institution which has provided its services to many local and international
                                clients, we are capable of providing innovative and out of the box solutions to meet any
                                requirement.
                                Our designs are carried out in conformity to internationally recognized standards; BS,
                                IEC, IEEE, NFPA and any local authority regulations applicable to the particular
                                project.
                                At APCL, our paramount priority is to create an output that we are proud of. We will go
                                to any length to create a tailor-made solution and have proven ourselves by providing
                                impeccable designs in due time.
                            </p>

                    </div>

                    <div class="heading-body">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <div class="image  ">
                                    <img class="firstimg" width="1024" height="1024" src="<?php echo get_template_directory_uri(); ?>/./inc/img/download.jpg" alt="" loading="lazy">
                                </div>
                            </div>

                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <div class="design-text-content">
                                    <h3>Electrical Power Engineering​</h3>
                                    <p>Installation and Commissioning of GSM & IBS base stations
                                        Transmission Installations Microwave equipment installations Optical Fiber
                                        Networks</p>
                                </div>






                                <!-- modal1 start -->

                                <div class="row text-start">
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="service-text-content">
                                            <!-- Button trigger modal -->
                                            <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                                class="design-btn" data-bs-target="#modal1">
                                                More info...!
                                            </button>


                                            <div class="modal fade" id="modal1" data-bs-backdrop="static"
                                                data-bs-keyboard="false" tabindex="-1"
                                                aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-scrollable modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title " id="staticBackdropLabel ">
                                                                Electrical Power Engineering</h5>


                                                            <button type="button" class="btn-close"
                                                                data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15"
                                                                        height="15" fill="#42C8C4"
                                                                        class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                    </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>High voltage Grid Substations</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15"
                                                                        height="15" fill="#42C8C4"
                                                                        class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                    </svg></i>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Transmission and Distribution Lines</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15"
                                                                        height="15" fill="#42C8C4"
                                                                        class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                    </svg></i>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Medium voltage installations</p>
                                                                </div>
                                                                <div class="col-1"></div>

                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15"
                                                                        height="15" fill="#42C8C4"
                                                                        class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                    </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Low voltage installations</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15"
                                                                        height="15" fill="#42C8C4"
                                                                        class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                    </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Power System Protection Systems</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15"
                                                                        height="15" fill="#42C8C4"
                                                                        class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                    </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Substation Earthing Systems</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15"
                                                                        height="15" fill="#42C8C4"
                                                                        class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                    </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Low voltage installation earthing systems</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15"
                                                                        height="15" fill="#42C8C4"
                                                                        class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                    </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Lightning Protection Systems (LPS)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15"
                                                                        height="15" fill="#42C8C4"
                                                                        class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                    </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Interior, Exterior and Lighting Systems</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15"
                                                                        height="15" fill="#42C8C4"
                                                                        class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                    </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Generators</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15"
                                                                        height="15" fill="#42C8C4"
                                                                        class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                    </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Solar PV Systems</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-info"
                                                                data-bs-dismiss="modal">Close</button>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="col-lg-4 col-md-2 col-sm-12"></div>




                                </div>


                                <!-- modal end -->


                            </div>
                        </div>
                    </div>
                </div>

                
               <!--  Data Center -->
               <div class="row  ">

                <div class="heading-body1">
                    <div class="row revers-row flex-sm-row">
                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <div class="design-text-content1">
                                <h3 class="my-4">Data Center</h3>

                                <p class="design-para">Introduced Thermal Imaging of Electrical Installations to Sri Lankan industry and carrying out thermal imaging audits successfully. </p>

                                <!-- Button trigger modal -->
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#modal2">
                                    More info...!
                                </button>

                                <!-- Modal -->
                                <div class="modal fade" id="modal2" data-bs-backdrop="static"
                                    data-bs-keyboard="false" tabindex="-1"
                                    aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-scrollable modal-lg">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title " id="staticBackdropLabel ">
                                                    Thermography Survey</h5>
                                                <button type="button" class="btn-close"
                                                    data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-1"></div>
                                                    <div class="col-1">
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                            width="15" height="15" fill="#42C8C4"
                                                            class="bi bi-check-lg"
                                                            viewBox="0 0 16 16">
                                                            <path
                                                                d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                        </svg>
                                                    </div>

                                                    <div class="col-9">
                                                        <p>Medium Voltage Installation</p>
                                                    </div>
                                                    <div class="col-1"></div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-1"></div>
                                                    <div class="col-1">
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                            width="15" height="15" fill="#42C8C4"
                                                            class="bi bi-check-lg"
                                                            viewBox="0 0 16 16">
                                                            <path
                                                                d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                        </svg>
                                                    </div>

                                                    <div class="col-9">
                                                        <p>Low Voltage Installation</p>
                                                    </div>
                                                    <div class="col-1"></div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-1"></div>
                                                    <div class="col-1">
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                            width="15" height="15" fill="#42C8C4"
                                                            class="bi bi-check-lg"
                                                            viewBox="0 0 16 16">
                                                            <path
                                                                d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                        </svg>
                                                    </div>

                                                    <div class="col-9">
                                                        <p>Generator selection and preparation of generator operation logics</p>
                                                    </div>
                                                    <div class="col-1"></div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-1"></div>
                                                    <div class="col-1">
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                            width="15" height="15" fill="#42C8C4"
                                                            class="bi bi-check-lg"
                                                            viewBox="0 0 16 16">
                                                            <path
                                                                d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                        </svg>
                                                    </div>

                                                    <div class="col-9">
                                                        <p>Fuel distribution and storage system design</p>
                                                    </div>
                                                    <div class="col-1"></div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-1"></div>
                                                    <div class="col-1">
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                            width="15" height="15" fill="#42C8C4"
                                                            class="bi bi-check-lg"
                                                            viewBox="0 0 16 16">
                                                            <path
                                                                d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                        </svg>
                                                    </div>

                                                    <div class="col-9">
                                                        <p>Carrying out complete electrical designs for tier certifications</p>
                                                    </div>
                                                    <div class="col-1"></div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-1"></div>
                                                    <div class="col-1">
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                            width="15" height="15" fill="#42C8C4"
                                                            class="bi bi-check-lg"
                                                            viewBox="0 0 16 16">
                                                            <path
                                                                d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                        </svg>
                                                    </div>

                                                    <div class="col-9">
                                                        <p>Lighting Systems</p>
                                                    </div>
                                                    <div class="col-1"></div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-1"></div>
                                                    <div class="col-1">
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                            width="15" height="15" fill="#42C8C4"
                                                            class="bi bi-check-lg"
                                                            viewBox="0 0 16 16">
                                                            <path
                                                                d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                        </svg>
                                                    </div>

                                                    <div class="col-9">
                                                        <p>Earthing System</p>
                                                    </div>
                                                    <div class="col-1"></div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-1"></div>
                                                    <div class="col-1">
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                            width="15" height="15" fill="#42C8C4"
                                                            class="bi bi-check-lg"
                                                            viewBox="0 0 16 16">
                                                            <path
                                                                d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                        </svg>
                                                    </div>

                                                    <div class="col-9">
                                                        <p>Lightning Protection Systems (LPS)</p>
                                                    </div>
                                                    <div class="col-1"></div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-1"></div>
                                                    <div class="col-1">
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                            width="15" height="15" fill="#42C8C4"
                                                            class="bi bi-check-lg"
                                                            viewBox="0 0 16 16">
                                                            <path
                                                                d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                        </svg>
                                                    </div>

                                                    <div class="col-9">
                                                        <p>Surge Protection System</p>
                                                    </div>
                                                    <div class="col-1"></div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-1"></div>
                                                    <div class="col-1">
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                            width="15" height="15" fill="#42C8C4"
                                                            class="bi bi-check-lg"
                                                            viewBox="0 0 16 16">
                                                            <path
                                                                d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                        </svg>
                                                    </div>

                                                    <div class="col-9">
                                                        <p>Selection of Uninterrupted Power Supplies (UPS)</p>
                                                    </div>
                                                    <div class="col-1"></div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-1"></div>
                                                    <div class="col-1">
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                            width="15" height="15" fill="#42C8C4"
                                                            class="bi bi-check-lg"
                                                            viewBox="0 0 16 16">
                                                            <path
                                                                d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                        </svg>
                                                    </div>

                                                    <div class="col-9">
                                                        <p>Selection of busbars and cables</p>
                                                    </div>
                                                    <div class="col-1"></div>
                                                </div>

                                                
                                                <div class="row">
                                                    <div class="col-1"></div>
                                                    <div class="col-1">
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                            width="15" height="15" fill="#42C8C4"
                                                            class="bi bi-check-lg"
                                                            viewBox="0 0 16 16">
                                                            <path
                                                                d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                        </svg>
                                                    </div>

                                                    <div class="col-9">
                                                        <p>Selection of Battery banks</p>
                                                    </div>
                                                    <div class="col-1"></div>
                                                </div>

                                                  
                                                <div class="row">
                                                    <div class="col-1"></div>
                                                    <div class="col-1">
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                            width="15" height="15" fill="#42C8C4"
                                                            class="bi bi-check-lg"
                                                            viewBox="0 0 16 16">
                                                            <path
                                                                d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                        </svg>
                                                    </div>

                                                    <div class="col-9">
                                                        <p>Selection of Isolation transformers</p>
                                                    </div>
                                                    <div class="col-1"></div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-1"></div>
                                                    <div class="col-1">
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                            width="15" height="15" fill="#42C8C4"
                                                            class="bi bi-check-lg"
                                                            viewBox="0 0 16 16">
                                                            <path
                                                                d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                        </svg>
                                                    </div>

                                                    <div class="col-9">
                                                        <p>Selection of Power Distribution Units</p>
                                                    </div>
                                                    <div class="col-1"></div>
                                                </div>


                                                <div class="row">
                                                    <div class="col-1"></div>
                                                    <div class="col-1">
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                            width="15" height="15" fill="#42C8C4"
                                                            class="bi bi-check-lg"
                                                            viewBox="0 0 16 16">
                                                            <path
                                                                d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                        </svg>
                                                    </div>

                                                    <div class="col-9">
                                                        <p>Consulting and Conducting of Site acceptance tests for electrical related streams</p>
                                                    </div>
                                                    <div class="col-1"></div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-1"></div>
                                                    <div class="col-1">
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                            width="15" height="15" fill="#42C8C4"
                                                            class="bi bi-check-lg"
                                                            viewBox="0 0 16 16">
                                                            <path
                                                                d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                        </svg>
                                                    </div>

                                                    <div class="col-9">
                                                        <p>Simulation and Consulting of test criteria for Tier certifications (international certifications)</p>
                                                    </div>
                                                    <div class="col-1"></div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-1"></div>
                                                    <div class="col-1">
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                            width="15" height="15" fill="#42C8C4"
                                                            class="bi bi-check-lg"
                                                            viewBox="0 0 16 16">
                                                            <path
                                                                d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                        </svg>
                                                    </div>

                                                    <div class="col-9">
                                                        <p>Software simulations (Electrical)</p>
                                                    </div>
                                                    <div class="col-1"></div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-1"></div>
                                                    <div class="col-1">
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                            width="15" height="15" fill="#42C8C4"
                                                            class="bi bi-check-lg"
                                                            viewBox="0 0 16 16">
                                                            <path
                                                                d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                        </svg>
                                                    </div>

                                                    <div class="col-9">
                                                        <p>Complete construction supervision consultancy of the electrical installation</p>
                                                    </div>
                                                    <div class="col-1"></div>
                                                </div>


                                                <div class="row">
                                                    <div class="col-1"></div>
                                                    <div class="col-1">
                                                        <svg xmlns="http://www.w3.org/2000/svg"
                                                            width="15" height="15" fill="#42C8C4"
                                                            class="bi bi-check-lg"
                                                            viewBox="0 0 16 16">
                                                            <path
                                                                d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                        </svg>
                                                    </div>

                                                    <div class="col-9">
                                                        <p>Complete testing and commissioning consultancy</p>
                                                    </div>
                                                    <div class="col-1"></div>
                                                </div>

                                                
                                                



                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-info"
                                                    data-bs-dismiss="modal">Close</button>

                                            </div>
                                        </div>
                                    </div>
                                </div>






                            </div>







                        </div>

                        <div class="col-lg-6 col-md-6 col-sm-12">
                            <div class="image1 mt-4">
                                <img width="1024" height="1024"
                                    src="<?php echo get_template_directory_uri(); ?>/./inc/service-img/TRANSMISSION_569x319.jpg" alt=""
                                    loading="lazy">
                            </div>


                        </div>
                    </div>
                </div>
             </div>
            <!-- Thermography Survey end -->





                <div class="row">
                    <div class="heading-body">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <div class="image">
                                    <img class="3rdimg" width="1024" height="1024" src="<?php echo get_template_directory_uri(); ?>/./inc/img/download.jpg" alt="" loading="lazy">
                                </div>
                            </div>

                            <div class="col-lg-6 col-md-6 col-sm-12">
                                <div class="design-text-content">
                                    <h3>Electrical</h3>
                                    <p>Installation and Commissioning of GSM & IBS base stations
                                        Transmission Installations Microwave equipment installations Optical Fiber
                                        Networks</p>
                                </div>

                                


                                <!-- modal3 start -->

                                <div class="row text-start">
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                       <div class="service-text-content">
                                          <!-- Button trigger modal -->
                                          <button type="button" class="btn btn-primary" data-bs-toggle="modal" class="design-btn"
                                          data-bs-target="#modal3">
                                          More info...!
                                      </button>
                                           

                                      <div class="modal fade" id="modal3" data-bs-backdrop="static"
                                                        data-bs-keyboard="false" tabindex="-1"
                                                        aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                        <div class="modal-dialog modal-dialog-scrollable modal-lg">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title " id="staticBackdropLabel ">
                                                                        Electrical </h5>

                                                                        
                                                                    <button type="button" class="btn-close"
                                                                        data-bs-dismiss="modal"
                                                                        aria-label="Close"></button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                                <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                              </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Medium Voltage installations</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                                <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                              </svg></i>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Low Voltage installations</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                                <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                              </svg></i>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Lightning Protection Systems (LPS)</p>
                                                                        </div>
                                                                        <div class="col-1"></div>

                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                                <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                              </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Interior, Exterior and Lighting Systems</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                             <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                                <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                              </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Earthing Systems</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                             <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                                <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                              </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Transformer Capacity estimation</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                             <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                                <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                              </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Generator sizing</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                             <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                                <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                              </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Solar PV Systems</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                   <!-- jiiii -->
                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                             <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                                <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                              </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Extra Low Voltage (ELV) installation</p>
                                                                            <div class="row">
                                                                                <div class="col-2">
                                                                                    <div class="new-icon">
                                                                                        <i class="fa-solid fa-circle-half-stroke list-circle"></i>
                                                                                    </div>
                                                                                </div>
                                
                                                                                <div class="col-10">
                                                                                    <p class="sub-list-content">CCTV</p>
                                                                                </div>
                                                                            </div>
                                
                                                                            <div class="row">
                                                                                <div class="col-2">
                                                                                    <div class="new-icon">
                                                                                        <i class="fa-solid fa-circle-half-stroke list-circle"></i>
                                                                                    </div>
                                                                                </div>
                                
                                                                                <div class="col-10">
                                                                                    <p class="sub-list-content">Data network</p>
                                                                                </div>
                                                                            </div>
                                
                                
                                                                            <div class="row">
                                                                                <div class="col-2">
                                                                                    <div class="new-icon">
                                                                                        <i class="fa-solid fa-circle-half-stroke list-circle"></i>
                                                                                    </div>
                                                                                </div>
                                
                                                                                <div class="col-10">
                                                                                    <p class="sub-list-content">Telephone</p>
                                                                                </div>
                                                                            </div>
                                
                                
                                                                            <div class="row">
                                                                                <div class="col-2">
                                                                                    <div class="new-icon">
                                                                                        <i class="fa-solid fa-circle-half-stroke list-circle"></i>
                                                                                    </div>
                                                                                </div>
                                
                                                                                <div class="col-10">
                                                                                    <p class="sub-list-content">Access Control Systems</p>
                                                                                </div>
                                                                            </div>
                                
                                
                                                                            <div class="row">
                                                                                <div class="col-2">
                                                                                    <div class="new-icon">
                                                                                        <i class="fa-solid fa-circle-half-stroke list-circle"></i>
                                                                                    </div>
                                                                                </div>
                                
                                                                                <div class="col-10">
                                                                                    <p class="sub-list-content">Public Addressing (PA) Systems</p>
                                                                                </div>
                                                                            </div>
                                
                                
                                                                            <div class="row">
                                                                                <div class="col-2">
                                                                                    <div class="new-icon">
                                                                                        <i class="fa-solid fa-circle-half-stroke list-circle"></i>
                                                                                    </div>
                                                                                </div>
                                
                                                                                <div class="col-10">
                                                                                    <p class="sub-list-content">MATV/IPTV</p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>


                                                                    

                                                                 

                                                                  

                                                                  

                                                               

                                                                  
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-info"
                                                                        data-bs-dismiss="modal">Close</button>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                       </div>

                                    </div>

                                    <div class="col-lg-4 col-md-2 col-sm-12"></div>




                                </div>


                                <!-- modal 3 end -->



                                 <!-- modal4 start -->

                                 <div class="row text-start mt-4">
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="service-text-content">
                                            <!-- Button trigger modal -->
                                            <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                                class="design-btn" data-bs-target="#modal4">
                                                More info...!
                                            </button>


                                            <div class="modal fade" id="modal4" data-bs-backdrop="static"
                                                data-bs-keyboard="false" tabindex="-1"
                                                aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-scrollable modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title " id="staticBackdropLabel ">
                                                                Mechanical services</h5>


                                                            <button type="button" class="btn-close"
                                                                data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15"
                                                                        height="15" fill="#42C8C4"
                                                                        class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                    </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Medium Voltage installations</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15"
                                                                        height="15" fill="#42C8C4"
                                                                        class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                    </svg></i>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Low Voltage installations</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15"
                                                                        height="15" fill="#42C8C4"
                                                                        class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                    </svg></i>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Lightning Protection Systems (LPS)</p>
                                                                </div>
                                                                <div class="col-1"></div>

                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15"
                                                                        height="15" fill="#42C8C4"
                                                                        class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                    </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Interior, Exterior and Lighting Systems</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15"
                                                                        height="15" fill="#42C8C4"
                                                                        class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                    </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Earthing Systems</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15"
                                                                        height="15" fill="#42C8C4"
                                                                        class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                    </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Transformer Capacity estimation</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15"
                                                                        height="15" fill="#42C8C4"
                                                                        class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                    </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Generator sizing</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15"
                                                                        height="15" fill="#42C8C4"
                                                                        class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                    </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Solar PV Systems</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15"
                                                                        height="15" fill="#42C8C4"
                                                                        class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                    </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Extra Low Voltage (ELV) installation</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                          

                                                            
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-info"
                                                                data-bs-dismiss="modal">Close</button>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="col-lg-4 col-md-2 col-sm-12"></div>




                                </div>


                                <!-- moda4 end -->

                                
                                 <!-- modal5 start -->

                                 <div class="row text-start mt-4">
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="service-text-content">
                                            <!-- Button trigger modal -->
                                            <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                                class="design-btn" data-bs-target="#modal5">
                                                More info...!
                                            </button>


                                            <div class="modal fade" id="modal5" data-bs-backdrop="static"
                                                data-bs-keyboard="false" tabindex="-1"
                                                aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-scrollable modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title " id="staticBackdropLabel ">
                                                                Plumbing</h5>


                                                            <button type="button" class="btn-close"
                                                                data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15"
                                                                        height="15" fill="#42C8C4"
                                                                        class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                    </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Water Supply Systems</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15"
                                                                        height="15" fill="#42C8C4"
                                                                        class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                    </svg></i>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Sewer and Wastewater Systems</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15"
                                                                        height="15" fill="#42C8C4"
                                                                        class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                    </svg></i>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Storm Water Systems</p>
                                                                </div>
                                                                <div class="col-1"></div>

                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15"
                                                                        height="15" fill="#42C8C4"
                                                                        class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path
                                                                            d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                    </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Pool and Spa</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                         

                                                            

                                                            
                                                            


                                                          

                                                          

                                                            
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-info"
                                                                data-bs-dismiss="modal">Close</button>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="col-lg-4 col-md-2 col-sm-12"></div>




                                </div>


                                <!-- moda5 end -->






                            </div>
                        </div>
                    </div>
                </div>

                <!-- <div class="row">
                   
                    <div class="heading-body1">
                        <div class="row">
                            <div class="col-6">
                                <div class="design-text-content1">
                                    <h3>Telecommunication and infrastructure Solutions</h3>
                                    <p>Installation and Commissioning of GSM & IBS base stations
                                        Transmission Installations Microwave equipment installations Optical Fiber Networks</p>
                                </div>
                            </div>

                            <div class="col-6">
                                <div class="image1">
                                    <img width="1024" height="1024"
                                        src="./inc/img/design/download.jpg" alt="" loading="lazy">     
                                </div>
                            </div>
                        </div>
                    </div>
                </div> -->

            </div>
        </section>
    </div>
    <!-- design category end -->


    <!-- body content end -->


<?php
get_footer();
  ?>
  