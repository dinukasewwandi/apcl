<?php
/*
 * Template Name: Electrical Safety Audits
 
 */
?>
<?php
 get_header();

  ?>

<!-- banner start -->
   
    <div class="banner-img " style="  background-image: url('<?php echo get_template_directory_uri(); ?>/./inc/img/banners-img/electricalsafety-banner.png');">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
               <!-- <img src="./inc/img/slider2.jpg" alt=""> -->
            </div>
        </div>
       
    </div>
 
  <!-- banner end -->

<div class="ash-header">
        <div class="container ash-container pb-3 pt-4">
            <div class="row">
                <div class="col-lg-1 col-md-1"></div>
                <div class="col-lg-10 col-md-10 col-sm-12">
                    <h4>Electrical Safety Audits</h4>
                </div>

                <div class="col-lg-1 col-md-1"></div>
            </div>
        </div>
    </div>
</div>

<div class="container">
        <div class="row">
            <div class="col-lg-1 col-md-1"></div>
            <div class="col-lg-10 col-md-10 col-sm-12">
                <section class="qulity-para mb-3 mt-3">
                    <p>As an expert conducting Electrical Safety Audits since 2004, we evaluate Electrical Installations for their safety against effects to invaluable humans, livestock and expensive equipment by analyzing compliance requirement to BS/EN 7671 (IET Wiring Regulation) and other respective IEC standards. In Sri Lanka, all electrical installations are compelled to align minimally with regulations of BS 7671 as stipulated in Sri Lanka Electricity Act and we further endorse to evaluate all associated systems of Medium & Low Voltage Systems with other safety aspects.</p>

                </section>

                <div class="row mt-3 mb-5">
                    <div class="col-lg-12 col-sm-12 col-md-12">
                        <div class="row">
                            <div class="col-lg-8 col-md-12 col sm-12 qulity-list">
                          <ul>
                            <li>Visual Inspection on Service entrance, Alternative supply sources (i.e Generator), Electrical Distribution Boards/ panels, distribution paths, Final circuits etc</li>
                            <li>Degree of insulation levels of feeders & circuits (via Insulation Resistance test)</li>
                            <li>Inspection & Testing of Earthing System (Earth Electrode resistance)</li>
                            <li>Testing of Residual Current Circuit Breakers (RCCBs) for ensuring fault protection</li>
                            <li>Testing of Earth Fault Loop Impedance & Prospective Short Circuit Current</li>
                            <li>Coordination among Overcurrent Protective Devices (OCPD) and Cables</li>
                            <li>Overcurrent and Earth Fault protection coordination</li>
                            <li>Evaluation on Electrical Housekeeping, Energy Housekeeping, Maintenance Procedures, Safety Procedures etc</li>
                            <li>Testing of Protection Relays (ELR, EFR, PFR, Numerical Relays) for their tripping characteristics and effective operation with Secondary or Primary Injection</li>
                            <li>Infrared Thermography survey to identify thermal anomalies under loaded conditions</li>
                            <li>Lightning Protection System (LPS) compliance to IEC 62305 by examining coverage & condition of External Lightning Protection Systems and effectiveness of Internal Overvoltage Protective measures (i.e. SPDs)</li>
                            <li>Evaluating condition of aged Overcurrent Protective Devices with Primary Injection</li>
                            <li>Evaluation of correct polarity, continuity and condition of socket outlets</li>
                            <li>Safety assessment of electrical appliances including extension cords (leads) through Portable Appliance Testing (PAT)</li>
                          </ul>
                            </div>
                            <div class="col-lg-4 col-md-12 col-sm-12 qulity-img ">
                                <img src="./inc/img/electrical-safety/electri1.jpg" alt="">
                                <img src="./inc/img/electrical-safety/electri2.jpg" alt="">
                                <img src="./inc/img/electrical-safety/electri3.jpg" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-1 col-md-1"></div>
        </div>
    </div>
<?php
get_footer();
  ?>

