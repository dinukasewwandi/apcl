


            
   
<div class="banner-img ">


    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
           <!-- <img src="./inc/img/slider2.jpg" alt=""> -->
        </div>
    </div>
   
</div>
   





