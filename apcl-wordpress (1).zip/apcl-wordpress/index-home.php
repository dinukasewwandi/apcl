<?php
/*
 * Template Name: Home Page
 
 */
?>
<?php
 get_header();
  ?>
  
  <!-- Body Content Start-->
    <!-- Slider -->
    <div id="carouselExampleCaptions" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="0" class="active"
                aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1"
                aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2"
                aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="<?php echo get_template_directory_uri(); ?>/inc/img/slider1.jpg" class="d-block w-100" alt="Slider 1">
                <div class="carousel-caption d-none d-md-block">
                    <h1>Sri Lankan Based Electrical Engineering Company</h1>
                </div>
            </div>
            <div class="carousel-item">
                <img src="<?php echo get_template_directory_uri(); ?>/inc/img/slider2.jpg" class="d-block w-100" alt="Slider 2">
                <div class="carousel-caption d-none d-md-block">
                    <h1>Sri Lankan Based Electrical Engineering Company</h1>
                </div>
            </div>
            <div class="carousel-item">
                <img src="<?php echo get_template_directory_uri(); ?>/inc/img/slider1.jpg" class="d-block w-100" alt="Slider 3">
                <div class="carousel-caption d-none d-md-block">
                    <h1>Sri Lankan Based Electrical Engineering Company</h1>
                </div>
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions"
            data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions"
            data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
    
    
   <!-- About Section -->
    <div class="section" id="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="headerBold text-center">
                        <h1><b>Electrical Engineering Consulting Company in Sri Lanka</b></h1>
                    </div>
                </div>
            </div>

            <div class="row ">
                <div class="col-lg-6 col-md-6 col-sm-12 experence-img">
                    <!-- <div class="content-section" style="background-image: url(inc/img/about_section.jpg);">
                </div> -->
                    <img src="<?php echo get_template_directory_uri(); ?>/inc/img/about_section.jpg" alt="">
                </div>

                <div class="col-lg-6 col-md-6 col-sm-12">

                    <div class="experence-section mt-3">
                        <!-- <svg xmlns="http://www.w3.org/2000/svg" width="20" height="16" fill="black" class="bi bi-dash-lg" viewBox="0 0 16 16">
                    <path fill-rule="evenodd" d="M2 8a.5.5 0 0 1 .5-.5h11a.5.5 0 0 1 0 1h-11A.5.5 0 0 1 2 8Z"/>
                  </svg>  -->
                        <img src="<?php echo get_template_directory_uri(); ?>/./inc/img/remove.png" alt="">
                        <p>Growing with Clients</p>
                        <p></p>
                    </div>

                    <div class="experence-section-para">
                        <h1 class="electrical"> <b>18 Years of <br> Experience</b> </h1> <br>
                        <p>Amith power Consultanta (PVT)Ltd was estalished in 2003 with the main Electrical & Power
                            System Consultancy ranging from High Voltage to Low Systems.</p>

                        <p>The company has sustaned around 2 decades with its expertise,professiona and trust of
                            services delivered to clients</p>
                    </div>
                </div>
            </div>



        </div>
    </div>
 
       <!-- Our Services -->
    <div class="section" id="service_area">
        <div class="container">
            <div class="row">
                <div class="header-content">
                    <h1 class="header">our <span class="blue">services</span></h1>
                    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nihil quia blanditiis quisquam quaerat.
                    </p>
                </div>

                <div class="col-xm-12 col-sm-12 col-md-6 col-lg-6">
                    <div class="row">
                        <div class=" col-sm-12">
                            <div class="icon">
                                <i class="fa-regular fa-object-group"></i>
                            </div>

                        </div>

                        <div class=" col-sm-12">
                            <div class="content">
                                <h2 class="text-effect">DESIGN, MODELLING & SIMULATIONS</h2>
                                <p>Electrical Power & MEP Design services for Urban development, Condominiums,
                                    Residential, Commercial & Industrial sectors</p>
                                <button class="effect-button">Read More</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xm-12 col-sm-12 col-md-6 col-lg-6">
                    <div class="row">
                        <div class=" col-sm-12">
                            <div class="icon">
                                <i class="fa-solid fa-check"></i>
                            </div>

                        </div>

                        <div class=" col-sm-12">
                            <div class="content">
                                <h2 class="text-effect">TESTING & COMMISSIONING</h2>
                                <p>Testing Low & Medium Voltage Installations during Commissioning and preventive
                                    maintenance routine tests, Thermography survey</p>
                                <button class="effect-button">Read More</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="row">
                <div class="col-xm-12 col-sm-12 col-md-6 col-lg-6">
                    <div class="row">
                        <div class=" col-sm-12">
                            <div class="icon">
                                <i class="fa-solid fa-shield-halved"></i>
                            </div>

                        </div>

                        <div class=" col-sm-12">
                            <div class="content">
                                <h2 class="text-effect">ELECTRICAL SAFETY AUDITS</h2>
                                <p>Periodic safety inspections & Tests of Electrical Installations as per BS 7671
                                    Standard (18th Edition) for periodic inspections and CEB/Leco certification</p>
                                <button class="effect-button">Read More</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xm-12 col-sm-12 col-md-6 col-lg-6">
                    <div class="row">
                        <div class=" col-sm-12">
                            <div class="icon">
                                <i class="fa-solid fa-file-shield"></i>
                            </div>

                        </div>

                        <div class=" col-sm-12">
                            <div class="content">
                                <h2 class="text-effect">PROJECT MANAGEMENT</h2>
                                <p>Delivering project goals satisfying Time, Cost & Quality with expert professional
                                    team</p>
                                <button class="effect-button">Read More</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-xm-12 col-sm-12 col-md-6 col-lg-6">
                    <div class="row">
                        <div class=" col-sm-12">
                            <div class="icon">
                                <i class="fa-solid fa-earth-americas"></i>
                            </div>

                        </div>

                        <div class=" col-sm-12">
                            <div class="content">
                                <h2 class="text-effect">TURNKEY PROJECTS</h2>
                                <p>All services in single package: Design, Supply, Install, Project Management, Testing
                                    & Commissioning</p>
                                <button class="effect-button">Read More</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xm-12 col-sm-12 col-md-6 col-lg-6">
                    <div class="row">
                        <div class=" col-sm-12">
                            <div class="icon">
                                <i class="fa-solid fa-toolbox"></i>
                            </div>

                        </div>

                        <div class=" col-sm-12">
                            <div class="content">
                                <h2 class="text-effect">TEST EQUIPMENT HIRING</h2>
                                <p>Rental of Electrical test instrument for Low Voltage & Medium Voltage Installation
                                    testing</p>
                                <button class="effect-button">Read More</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
       
    <!--our services-->

   
    <!-- Why choose us section -->
    <div class="section" id="why-choose">
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-6 col-lg-6">
                    <div class="wc-content">
                        <h1 class="header">why <span class="blue">choose us</span></h1>
                        <div class="wc-list">

                            Amithi Power Consultants Pvt. Ltd is a Sri Lanka based Electrical Engineering consulting
                            company established in 2004 providing Design Consultancy (Electrical Power & MEP), Testing,
                            Commissioning, Auditing & Servicing of Electrical Installations for both local &
                            international parties. We also provide design and consultancy services for building services
                            engineering projects. APCL maintains a close relationship with the clients and has become a
                            renowned company in Sri Lanka.

                            We strive to deliver high quality services in a timely manner which incorporates fullest
                            attention to detail and compliance standards.
                        </div>
                    </div>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-6">
                    <div class="wcback-img">
                        <div class="wc-img-section" style="background-image: url(<?php echo get_template_directory_uri(); ?>/inc/img/slider1.jpg) ;"></div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    </div>
    <!-- Our clients section -->
    <div class="section" id="our-clients">
        <div class="container">
            <div class="text-center">
                <h1 class="header">our <span class="blue">clients</span></h1>
            </div>
            <div class="oc-slider">
                <div class="owl-one owl-carousel owl-theme text-center">
                    <div class="item">
                        <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/inc/img/clients/CBL.png" alt="">
                    </div>
                    <div class="item">
                        <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/inc/img/clients/CEB.png" alt="">
                    </div>
                    <div class="item">
                        <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/inc/img/clients/CEYPETCO.png" alt="">
                    </div>
                    <div class="item">
                        <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/inc/img/clients/CTC.png" alt="">
                    </div>
                    <div class="item">
                        <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/inc/img/clients/DIMO.png" alt="">
                    </div>
                    <div class="item">
                        <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/inc/img/clients/GSK.png" alt="">
                    </div>
                    <div class="item">
                        <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/inc/img/clients/HavelockCity.png" alt="">
                    </div>
                    <div class="item">
                        <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/inc/img/clients/Hayleys.png" alt="">
                    </div>
                    <div class="item">
                        <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/inc/img/clients/Insee.png" alt="">
                    </div>
                    <div class="item">
                        <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/inc/img/clients/PORT-CITY.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Projects section -->
    <div class="section bg-gray" id="design-projects">
        <div class="container">
            <div class="text-center">
                <h1 class="header">recent <span class="blue"> projects</span></h1>
            </div>
            <div class="dp-slider">
                <div class="owl-two owl-carousel owl-theme text-center">
                    <div class="item">
                        <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/inc/img/about_section.jpg" alt="">
                        <div class="p-name text-center mt-3">
                            <span>Electrical Power Projects</span>
                        </div>
                    </div>
                    <div class="item">
                         <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/inc/img/about_section.jpg" alt="">
                        <div class="p-name text-center mt-3">
                            <span>Renewable Energy Projects</span>
                        </div>
                    </div>
                    <div class="item">
                         <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/inc/img/about_section.jpg" alt="">
                        <div class="p-name text-center mt-3">
                            <span>Earthing System Design & Analysis</span>
                        </div>
                    </div>
                    <div class="item">
                        <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/inc/img/about_section.jpg" alt="">
                        <div class="p-name text-center mt-3">
                            <span>Building Services</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Contact banner section -->
    <!-- <div class="section" id="contact-banner">
        <div class="container">
            <div class="text-center">
                <h2 class="header">Electrical <span class="blue">simiulation software</span></h2>
                <h4 class="mt-3">with commercial license</h4>
                <a class="btn btn-primary mt-3" href="#">contact us <i class="fa fa-arrow-right"></i></a>
            </div>
        </div>
    </div> -->

    <!-- Body Content End-->
    <!-- Body Content End-->
   
</body>

</html>
    <!-- Body Content End-->
    <?php
get_footer();
  ?>
  