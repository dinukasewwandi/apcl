<?php
/*
 * Template Name: Training
 
 */
?>
<?php
 get_header();

  ?>
  
 
<!-- banner start -->
   
    <div class="banner-img " style="  background-image: url('<?php echo get_template_directory_uri(); ?>/./inc/img/banners-img/trainning-banner.png');">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
               <!-- <img src="./inc/img/slider2.jpg" alt=""> -->
            </div>
        </div>
       
    </div>
 
  <!-- banner end -->
  
     <div class="ash-header">
        <div class="container ash-container pb-3 pt-4">
            <div class="row">
                <div class="col-lg-1 col-md-1"></div>
                <div class="col-lg-10 col-md-10 col-sm-12">
                    <h4>Trainning</h4>
                </div>

                <div class="col-lg-1 col-md-1"></div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-lg-1 col-md-1"></div>
            <div class="col-lg-10 col-md-10 col-sm-12">
                <section class="qulity-para my-5">
                    <p>We are registered with IESL (Institute of Engineers Sri Lanka) as a “Recognized Training Organization” comprised with qualified engineers. We carryout training programs under strict supervision by NAITA and all elements of APCL internal staff.</p>

                    <p>We provide internship opportunities for Electrical Engineering undergraduates each year. By the beginning of 2020, we had trained over 100 students from state universities, private universities in Sri Lanka & overseas.</p>

                    <p>
                        <ul>
                            <li>University of Moratuwa (UoM), Sri Lanka</li>
                            <li>University of Peradeniya (UoP), Sri Lanka</li>
                            <li>University of Ruhuna (UoR), Sri Lanka</li>
                            <li>Jawaharlal Nehru Technological University (JNTU), India</li>
                            <li>General Sir John Kotelawala Defence University (KDU), Sri Lanka</li>
                         
                        </ul>
                    </p>

                    <p>Additionally we provide ad-hoc internship opportunities for interested parties.</p>

                    <p>A customized program is conducted for interns covering the theoretical knowledge and hands-on experience with day today tasks varying from Designing works to Tests and Commissioning.</p>
                    <p class="contact-trainning-para">For any inquiry feel free to<a href=""> contact us.</a></p>
                </section>
            </div>
            <div class="col-lg-1 col-md-1"></div>
        </div>
    </div>

  
  <?php
get_footer();
  ?>