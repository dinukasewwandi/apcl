<?php
/*
 * Template Name: Testing & Commising
 
 */
?>
<?php
 get_header();

  ?>
<!-- banner start -->
   
    <div class="banner-img " style="  background-image: url('<?php echo get_template_directory_uri(); ?>/./inc/img/banners-img/testingandcommising-banner.png');">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
               <!-- <img src="./inc/img/slider2.jpg" alt=""> -->
            </div>
        </div>
       
    </div>
 
  <!-- banner end -->

    <!-- Body Content Start-->

    <div class="body-content  pt-3 ">

        <div class="container">
            <div class="row">

                <div class="col-lg-12 col-md-12 col-sm-12">
                  
                    <div class="section" id="design">

                        <div class="section-header text-center ">
                            <p class="h2 fw-bolder">Testing & Commissioning</p>
                            <br>

                            <p>We conduct testing of all Low Voltage & High Voltage systems. </p>

                            <p>May it be commissioning of a new installation or preventive maintenance routine tests or troubleshooting to diagnose specific issues.</p>


                        </div>
                    </div>


                    
                </div>


                    <!-- design category Start -->
                    
                    <div class="testig-category">
                        <div class="row">
                            <dic class="col-lg-12 col-md-12 col-sm-12">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-12 text-center testing-col mt-5 ">
                                        <div class="image ">
                                            <img class="mb-3 resting-img-one"
                                                src="<?php echo get_template_directory_uri(); ?>/./inc/service-img/LIGHTNING_569x319.jpg" alt=""
                                                loading="lazy">

                                                <p><b>Protection Relay Testing</b></p>

                                                <p >Relay characteristics are tested against specified tripping curves (ex: IEC 60255) with APCL professional test instrument “Megger Sverker 900”.</p>
                                                <p >Common Relay Types : Current, Voltage, Frequency, Power</p>
                                                <p><b>LV Relays :</b>  ELR, EFR, PFR etc</p>
                                                <p><b>HV Relays :</b>  Overcurrent, Earth Fault,  Over/under frequency, Differential Protection, Distance Protection, Neutral Voltage Displacement (NVD), Vector shift, ROCOF</p>
                                                <p>#Protection Relay Testing Lanka</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12  text-center testing-col mt-5">
                                        <div class="image ">
                                            <img  class="mb-3"
                                            src="<?php echo get_template_directory_uri(); ?>/./inc/service-img/TRANSMISSION_569x319.jpg" alt=""
                                            loading="lazy">
                                            

                                            <p><b>Energy Meter Calibration</b></p>

                                            <p>Calibration of Energy Meters (Electro-mechanical or Digital) will ensure correct performances and errors which account for reducing unnecessary financial losses and retrieving correct data for Energy Management Plans at facilities</p>

                                        </div>
                                    </div>
                                </div>
        
                                <div class="row ">
                                    <div class="col-lg-6 col-md-6 col-sm-12 text-center testing-col mt-5">
                                        <div class="image ">
                                            <img  class="mb-3"
                                                src="<?php echo get_template_directory_uri(); ?>/./inc/service-img/COMMERCIAL-resized.jpg" alt=""
                                                loading="lazy">

                                                <p><b>Primary Injection Testing</b></p>

                                                <p>Conducting Primary Injections testing of Circuit Breakers, Auto-Reclosers and all other over-current protective devices up to 3000 A. Ensures tripping performance, safeguarding your facility against catastrophic overcurrent origined failures.</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12  text-center testing-col mt-5">
                                        <div class="image ">
                                            <img  class="mb-3"
                                                src="<?php echo get_template_directory_uri(); ?>/./inc/service-img/CONSULTANCY_569x319.jpg" alt=""
                                                loading="lazy">

                                                <p><b>Insulation Resistance</b></p>

                                                <p>Insulation Resistance is measured in Low Voltage Installation (< 1 kV) and High Voltage Installations (> 1 kV) to assure the dedicated minimum insulation established prior to energizing.
                                                    Recommended test for periodic installation evaluation.
                                                    
                                                    </p>
                                        </div>
                                    </div>
                                </div>
        
                                <div class="row ">
                                    <div class="col-lg-6 col-md-6 col-sm-12 text-center testing-col mt-5">
                                        <div class="image ">
                                            <img  class="mb-3"
                                                src="<?php echo get_template_directory_uri(); ?>/./inc/service-img/EARTHING_569x319.jpg" alt=""
                                                loading="lazy">

                                                <p>
                                                    <b>Earth Electrode Resistance</b>
                                                </p>

                                                <p>Earthing systems are checked for individual & mesh earth-electrode resistance as per IEEE 81..</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12  text-center testing-col mt-5">
                                        <div class="image ">
                                            <img  class="mb-3"
                                                src="<?php echo get_template_directory_uri(); ?>/./inc/service-img/INDUSTRIAL_569x319.jpg" alt=""
                                                loading="lazy">

                                                <p><b> Soild Resistivity</b></p>

                                                <p>We test Electrical Resistivity of Soil using 4 Terminal Earth Tester.
                                                </p>
                                                <p>The measurements are crucial for designing Earthing Systems for Generating Stations, Wind Power Plants, LV/MV Installations, Substations & Lightning Protection Systems where the designs shall meet maximum Earth Electrode Resistances or Touch Voltage limits as per IEEE.</p>
                                                <p>We strategically measure Soil Resistivity values orienting design goals and provide soil model reports for aforementioned requirements.</p>
                                        </div>
                                    </div>
                                </div>
        
                                <div class="row ">
                                    <div class="col-lg-6 col-md-6 col-sm-12 text-center testing-col mt-3">
                                        <div class="image ">
                                            <img  class="mb-3"
                                                src="<?php echo get_template_directory_uri(); ?>/./inc/service-img/POWER_569x319.jpg" alt=""
                                                loading="lazy">

                                                <p><b>Power Quality & Harmonic Analysis</b></p>

                                                <p>We conduct comprehensive Electrical Data Logging, Power Quality Analysis & Harmonic Analysis for industrial installations and Solar PV installations.</p>
                                                                            <p><b>Logging parameters:</b></p>
                                                                            <p>Voltage, Current, Frequency, Demand (kVA), Energy, Harmonics (up to 50th harmonic, THD, TDD) , Events (Swell. Dips, Interruptions, Transient Overvoltage Impulse, Inrush Currents)</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12  text-center testing-col mt-3">
                                        <div class="image ">
                                            <img  class="mb-3"
                                                src="<?php echo get_template_directory_uri(); ?>/./inc/service-img/TRANSMISSION_569x319.jpg" alt=""
                                                loading="lazy">

                                                <p><b>Thermography Surveys</b></p>
                                                <p>Infrared thermography surveys conducted by APCL’s consultants & engineers will inspect Electrical & Mechanical systems for anomalies.
                                                </p>
                                                <p>The detailed systematic report with recommendations will aid you to understand the hidden issues and corrective measures to be taken.</p>
                                                <p>We introduced thermography for Electrical Consultancy in 2010 helping Sri Lankan & overseas industries to run safely.</p>
                                                <p>Our experience in Electrical Design & Testing have contributed remarkably to conduct Thermal Imaging / Thermography more technically. </p>
                                                <p>#Thermography Lanka</p>
                                        </div>
                                    </div>
                                </div>
        
                                <div class="row ">
                                    <div class="col-lg-6 col-md-6 col-sm-12 text-center testing-col mt-3">
                                        <div class="image ">
                                            <img  class="mb-3"
                                                src="<?php echo get_template_directory_uri(); ?>/./inc/service-img/COMMERCIAL-resized.jpg" alt=""
                                                loading="lazy">

                                                <p><b>Earth Fault Loop</b></p>

                                                <p>Residual Current Devices (RCD) which are the elemental component of fault protection in Low Voltage Systems shall be checked for their specified operation prior to commercial operation and periodic auditing. </p>
                                                                            <p>We test RCCBs & RCBOs with commercial test instrument and provide recommendations based on tripping time characteristics and statistical nature.</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12  text-center testing-col mt-3">
                                        <div class="image ">
                                            <img  class="mb-3"
                                                src="<?php echo get_template_directory_uri(); ?>/./inc/service-img/INDUSTRIAL_569x319.jpg" alt=""
                                                loading="lazy">

                                                <p><b> RCD (RCCB, RCBO)</b></p>

                                                <p>Residual Current Devices (RCD) which are the elemental component of fault protection in Low Voltage Systems shall be checked for their specified operation prior to commercial operation and periodic auditing. 

                                                </p>
                                                <p>We test RCCBs & RCBOs with commercial test instrument and provide recommendations based on tripping time characteristics and statistical nature.</p>
                                        </div>
                                    </div>
                                </div>
        
                                <div class="row ">
                                    <div class="col-lg-6 col-md-6 col-sm-12 text-center testing-col mt-3">
                                        <div class="image ">
                                            <img  class="mb-3"
                                                src="<?php echo get_template_directory_uri(); ?>/./inc/service-img/CONSULTANCY_569x319.jpg" alt=""
                                                loading="lazy">
                                                <p><b>Hi-Pot (Withstand Voltage)</b></p>

                                                <p>High Voltage Withstand Test (or Pressure Testing) is conducted for both Low Voltage and High Voltage Installations.</p>
                                                                            <p>We carry out tests up to 100 kV as per IEC test methodologies for different specimen types (Cables, Transformers, Bus bars, Switchgear etc).</p>
                                                                            <p>#High Voltage Testing Lanka #Hipot Lanka</p>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-12  text-center testing-col mt-3">
                                        <div class="image ">
                                            <img  class="mb-3"
                                                src="<?php echo get_template_directory_uri(); ?>/./inc/service-img/EARTHING_569x319.jpg" alt=""
                                                loading="lazy">

                                                <p><b>Portable Appliance Testing (PAT)</b></p>
                                                
                                                <p>Complete electrical design for Zam Gems
                                                    Building Colombo 04.</p>
                                        </div>
                                    </div>
                                </div>
                            </dic>
                        </div>
                        
                    </div>
                
                </div>



            </div>
            </section>
        </div>
        <!-- design category end -->
    </div>


    </div>
    </div>
    </div>
    <!-- Body Content End-->
  
  <?php
get_footer();
  ?>