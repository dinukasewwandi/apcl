<?php
/*
 * Template Name: Products
 
 */
?>
<?php
 get_header();

  ?>

  <!-- banner start -->
   
    <div class="banner-img " style="  background-image: url('<?php echo get_template_directory_uri(); ?>/./inc/img/banners-img/products-banner.png');">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
               <!-- <img src="./inc/img/slider2.jpg" alt=""> -->
            </div>
        </div>
       
    </div>
 
  <!-- banner end -->
     <!--  body content start -->
     <div class="body-content pb-5 pt-3 ">

<div class="container">
    <div class="row">
        <div class="col-lg-1"></div>
        <div class="col-lg-10">
            <div class="section" id="product">

                <div class="section-header text-center">
                    <p class="h1 fw-bolder"> Test Equipment Hiring</p>
                    <p class="h4 "> Electrical Test Instrument Rental Service</p>

                </div>

                <div class="logo-section my-2">
                    <div class="row brand-logo ">

                        <div class="col mt-4">
                            <img src="<?php echo get_template_directory_uri(); ?>/inc/img/product1__143x47.png" alt="">
                        </div>
                        <div class="col mt-4">
                            <img src="<?php echo get_template_directory_uri(); ?>/inc/img/product2_173x32.jpg" alt="">
                        </div>
                        <div class="col mt-4">
                            <img src="<?php echo get_template_directory_uri(); ?>/inc/img/product3_173x54.jpg" alt="">
                        </div>
                        <div class="col mt-4">
                            <img src="<?php echo get_template_directory_uri(); ?>/inc/img/product4_173x58.png" alt="">
                        </div>

                        <div class="col mt-4">
                            <img src="<?php echo get_template_directory_uri(); ?>/inc/img/product5_103x88.jpg" alt="" class="finalbrand">
                        </div>
                    </div>
                </div>

                <div class="product-section mt-5">
                    <div class="row product-img">
                        <div class="col-lg-3 col-md-3 col-sm-6 mt-4">
                            <div class="card">
                                <div class="card-start">
                                    <p class="make fontadding">MAKE : KYORITSU</p>
                                    <p class="h6 fontadding fw-bolder">CLAMP-ON-METER</p>
                                </div>
                                <div class="card-body text-center mt-3">
                                    <img src="<?php echo get_template_directory_uri(); ?>/inc/img/item1.png" class="multimeter" alt="">
                                </div>
                                <div class="card-end">
                                    <h6 class="modelfont">Model: SNAP 2002PA</h6>
                                </div>
                            </div>

                        </div>


                        <div class="col-lg-3 col-md-3 col-sm-6 mt-4 ">

                            <div class="card">
                                <div class="card-start">
                                    <p class="make fontadding">MAKE : FLUKE</p>
                                    <p class="h6 fontadding fw-bolder">DIGITAL MULTIMETER</p>
                                </div>
                                <div class="card-body text-center mt-3">
                                    <img src="<?php echo get_template_directory_uri(); ?>/inc/img/item2_122x238.jpg" class="multimeter" alt="">
                                </div>
                                <div class="card-end">
                                    <h6 class="modelfont">Model: Fluke 177</h6>
                                </div>
                            </div>
                        </div>


                        <div class="col-lg-3 col-md-3 col-sm-6 mt-4">
                            <div class="card">
                                <div class="card-start">
                                    <p class="make fontadding">MAKE : KYORITSU </p>
                                    <p class="h6 fontadding fw-bolder">INSULATION RESISTANCE & CONTIGUITY TESTER
                                    </p>
                                </div>
                                <div class="card-body text-center  bigimg mt-3">
                                    <img src="<?php echo get_template_directory_uri(); ?>/inc/img/item3 resize.png" alt="">
                                </div>
                                <div class="card-end">
                                    <h6 class="modelfont">Model: 3005A & 3007A</h6>
                                </div>
                            </div>
                        </div>


                        <div class="col-lg-3 col-md-3 col-sm-6 imgcard mt-4" >
                            <div class="card withoutborder">
                                <div class="card-start">
                                    <p class="make fontadding">MAKE : KYORITSU</p>
                                    <p class="h6 fontadding fw-bolder ">DIGITAL RCD (ELCB) TESTER</p>
                                </div>

                                <div class="card-body text-center bigimg mt-3 ">
                                    <img src="<?php echo get_template_directory_uri(); ?>/inc/img/item4 resize.png" alt="">
                                    


                                </div>
                                <div class="card-end">
                                  <h6 class="modelfont">Model: MODEL 5406A</h6>
                                </div>
                            </div>
                        </div>


                    </div>
                </div>


            </div>
        </div>
        <div class="col-lg-1"></div>


    </div>
</div>



</div>
<!--  body content end -->

<?php
get_footer();
  ?>