<?php
/*
 * Template Name: Qulity Policy
 
 */
?>
<?php
 get_header();

  ?>

  <!-- banner start -->
   
    <div class="banner-img " style="  background-image: url('<?php echo get_template_directory_uri(); ?>/./inc/img/banners-img/policy-banner.png');">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
               <!-- <img src="./inc/img/slider2.jpg" alt=""> -->
            </div>
        </div>
       
    </div>
 
  <!-- banner end -->
  
    <div class="ash-header">
        <div class="container ash-container pb-3 pt-4">
            <div class="row">
                <div class="col-lg-1 col-md-1"></div>
                <div class="col-lg-10 col-md-10 col-sm-12">
                    <h4>Quality Policy</h4>
                </div>

                <div class="col-lg-1 col-md-1"></div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
            <div class="col-lg-1 col-md-1"></div>
            <div class="col-lg-10 col-md-10 col-sm-12">
                <section class="qulity-para my-5">
                    <p>Amithi Power Consultants (Pvt) Ltd is an Electrical HV, MV, LV System Design, Testing,
                        Commissioning, Auditing and MEP Design company in Sri Lanka, which sets a benchmark in
                        addressing the requirement of the client while maintaining Quality Management System meeting ISO
                        9001:2015 standards, legal & stakeholder requirements.</p>
                    <p>We, APCL commit to develop a culture that ensures continual improvement of our Quality Management
                        System to improve our performance and attitude towards quality for the satisfaction of our
                        client. All required financial resources, Human resources, software, test equipment and tools
                        are committed by the company for the APCL team to deliver a right service at right time.</p>

                </section>
            </div>
            <div class="col-lg-1 col-md-1"></div>
        </div>
    </div>
  
  <?php
get_footer();
  ?>