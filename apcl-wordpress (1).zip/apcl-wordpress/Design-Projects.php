<?php
/*
 * Template Name: Design Projects
 
 */
?>
<?php
 get_header();

  ?>

<!-- banner start -->
   
    <div class="banner-img " style="  background-image: url('<?php echo get_template_directory_uri(); ?>/./inc/img/banners-img/designprojects-banner.png');">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
               <!-- <img src="./inc/img/slider2.jpg" alt=""> -->
            </div>
        </div>
       
    </div>
 
  <!-- banner end -->
  <!-- Body Content Start-->

  <div class="body-content  pt-3 ">

<div class="container">
    <div class="row">

        <div class="col-12">
            <div class="section" id="design">

                <div class="section-header text-center ">
                    <p class="h1 fw-bolder">DESIGN PROJECTS</p>


                </div>



            </div>


            <!-- design category Start -->
            <div class="design-categories">
                <section class="service-design">
                    <div class="container-fluid">


                        <!-- Lightning Protection Systems (LPS) -->
                        <div class="row  ">


                            <div class="heading-body">
                                <div class="row ">
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="image ">
                                            <img width="1024" height="1024" src="<?php echo get_template_directory_uri(); ?>/./inc/service-img/LIGHTNING_569x319.jpg" alt=""
                                                loading="lazy">
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="design-text-content">
                                            <h3 class="my-4 ">Lightning Protection Systems (LPS)​</h3>

                                            <p class="design-para">Lorem ipsum dolor sit, amet consectetur adipisicing elit. </p>


                                            <!-- Button trigger modal -->
                                            <button type="button" class="btn btn-primary" data-bs-toggle="modal" class="design-btn"
                                                data-bs-target="#modal1">
                                                More info...!
                                            </button>


                                            

                                            <!-- Modal -->
                                            <div class="modal fade" id="modal1" data-bs-backdrop="static"
                                                data-bs-keyboard="false" tabindex="-1"
                                                aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-scrollable modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title " id="staticBackdropLabel ">
                                                                Lightning Protection Systems (LPS)</h5>

                                                                
                                                            <button type="button" class="btn-close"
                                                                data-bs-dismiss="modal"
                                                                aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Consultancy for ‘Project Nucifera’ at
                                                                        Nestle Lanka PLC,
                                                                        Makandura (2016)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg></i>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Consultancy for Empire Residencies,
                                                                        Colombo (2016)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg></i>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Design and routine maintenance at Ceylon
                                                                        Tobacco Company
                                                                        (2015-2019)</p>
                                                                </div>
                                                                <div class="col-1"></div>

                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                    <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Dimo, Siyambalape (2013)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Inspection and Testing of Earth & LPS at
                                                                        Noratel
                                                                        International (Pvt) Ltd. (2013)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Dimo, Weliweriya (2013)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Evaluation of LPS, Earth Rod Resistance
                                                                        Test - Glaxo
                                                                        Wellcome Ceylon Ltd (2014)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Supply and Installation of a Lightning
                                                                        Protection System
                                                                        for Glaxo SmithKline Beecham (Pvt) Ltd
                                                                        (2014)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Supply and Installation of a Lightning
                                                                        Protection System
                                                                        and earth enhancement for Holcim Lanka
                                                                        Ltd (2014)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-info"
                                                                data-bs-dismiss="modal">Close</button>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>



                                        </div>








                                    </div>
                                </div>
                            </div>
                        </div>
                           <!-- Lightning Protection Systems (LPS) end -->




                           <!-- Transmission Line Designs -->
                        <div class="row  ">

                            <div class="heading-body1">
                                <div class="row revers-row flex-sm-row">
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="design-text-content1">
                                            <h3 class="my-4">Transmission Line Designs</h3>

                                            <p class="design-para">Lorem ipsum dolor sit, amet consectetur adipisicing elit. </p>

                                            <!-- Button trigger modal -->
                                            <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                                data-bs-target="#modal2">
                                                More info...!
                                            </button>

                                            <!-- Modal -->
                                            <div class="modal fade" id="modal2" data-bs-backdrop="static"
                                                data-bs-keyboard="false" tabindex="-1"
                                                aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-scrollable modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title " id="staticBackdropLabel ">
                                                                Transmission Line Designs</h5>
                                                            <button type="button" class="btn-close"
                                                                data-bs-dismiss="modal"
                                                                aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Commissioning and designing of the Sri Lanka’s first overhead bundle cable line for Senok Wind farm at Puttalum</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Proposal with a design of changing bare conductor distribution line to ABC distribution line at City Kurunegala for Ceylon Electricity Board (NWP) –Proposed due to insufficient clearance and to avoid direct contact.</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Consulted & Designed the 132 kV Transmission line of ACE Power (Embilipitiya).</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Consulted & Designed and Supervised modification of the 132 kV Transmission line of ACE Power (Embilipitiya) and CEB Grid substation.</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Consulted, Designed and Supervised 33kV Electrical Distribution Network, Perimeter and Street Lighting System Brandix India Apparel City – India.</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>


                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-info"
                                                                data-bs-dismiss="modal">Close</button>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>






                                        </div>







                                    </div>

                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="image1 mt-4">
                                            <img width="1024" height="1024" src="<?php echo get_template_directory_uri(); ?>/./inc/service-img/TRANSMISSION_569x319.jpg" alt=""
                                                loading="lazy">
                                        </div>


                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Transmission Line end -->




                        <!-- Earthing System Design & Analysis -->
                        <div class="row mobspace ">
                            <div class="heading-body">
                                <div class="row  ">
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="image mt-4">
                                            <img width="1024" height="1024" src="<?php echo get_template_directory_uri(); ?>/./inc/service-img/EARTHING_569x319.jpg" alt=""
                                                loading="lazy">
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="design-text-content ">
                                            <h3 class="my-4">Earthing System Design & Analysis</h3>

                                            <p class="design-para">Lorem ipsum dolor sit, amet consectetur adipisicing elit. </p>


                                            <!-- Button trigger modal -->
                                            <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                                data-bs-target="#modal3">
                                                More info...!
                                            </button>

                                            <!-- Modal -->
                                            <div class="modal fade" id="modal3" data-bs-backdrop="static"
                                                data-bs-keyboard="false" tabindex="-1"
                                                aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-scrollable modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title " id="staticBackdropLabel ">
                                                                EARTHING SYSTEM DESIGN & ANALYSIS</h5>
                                                            <button type="button" class="btn-close"
                                                                data-bs-dismiss="modal"
                                                                aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Evaluation of earthing and grounding system of “Lakvijaya” Power Station, Norochcholai in the perspective of electrical safety</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Designing of Earthing Systems for 220/132/11kV GSS “L” “M” & “N” Substations under “Greater Colombo Transmission & Distribution Loss Reduction Project” with ETAP (2017)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Designing of the earthing systems for Grid substation at Pallekele. (2013)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Designing of the earthing systems for Grid substation at Naula. (2013)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Designing of the earthing systems for Grid substation at Chunnakum. (2013)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Designing of the earthing systems for Grid substation at Maho. (2013)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Designing of the earthing systems for Grid substation at Habarana. (2013)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Earth Electrode Adequacy Test at Data Entry International Ltd (2013)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Annual Earth pit testing for Nestle Lanka PLC. (2014-2017)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Earth Rod Resistance test for Glaxo Smith Kline (Pvt) Ltd. (2014)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Providing of Earth Electrode Resistance Report to Nikini Automation System (Pvt) Ltd (2014)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Detailed design and hand calculation for the Earthing Design of New Galle substation and provision of detailed report to ABB Limited (SVAT) (2014)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Testing of 91 Nos of Earth Electrodes and evaluation of the lightning protection system at Nestle Lanka PLC. (2015)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Earth Electrode Testing, Testing & Analysing done at RR Donnelly Outsource (Pvt) Ltd. (2015)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Testing of Battery bank and Earthing System at Asia Power (Pvt) Ltd. (2015)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Testing of Earthing and Providing of a Chartered Engineering Certificate for AES Kelanitissa. (2015)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Earth Testing done for SmithKline Beecham (Pvt) Ltd. (2015)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Earthing Enhancement for SmithKline Bechame (Pvt) Ltd. (2016)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Earthing System design, Issuing of Chartered Engineer Certificate to IDawn Technologies. (2016)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Evaluation of earth system, Soil Resistivity and design of earthing system for proposed container office at CTC depot, Theldeniya. (2017)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-info"
                                                                data-bs-dismiss="modal">Close</button>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>



                                        </div>
                                        <!----Main content-->

                                    </div>

                                </div>
                            </div>

                        </div>
                        <!-- Earthing System Design & Analysis end -->



                        <!--  Substation Design -->
                        <div class="row ">

                            <div class="heading-body1">
                                <div class="row revers-row flex-sm-row ">
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="design-text-content1">
                                            <h3 class="my-4"> Substation Design</h3>

                                            <p class="design-para">Lorem ipsum dolor sit, amet consectetur adipisicing elit. </p>

                                            <!-- Button trigger modal -->
                                            <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                                data-bs-target="#modal4">
                                                More info...!
                                            </button>

                                            <!-- Modal -->
                                            <div class="modal fade" id="modal4" data-bs-backdrop="static"
                                                data-bs-keyboard="false" tabindex="-1"
                                                aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-scrollable modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="staticBackdropLabel">
                                                                Substation Design</h5>
                                                            <button type="button" class="btn-close"
                                                                data-bs-dismiss="modal"
                                                                aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Designing of cable systems (HV, LV and Control) for Chunnakam Substation.</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Designing of the LV substation for CTC Kandy leaf branch.</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Proposal of transformer paralleling at Matara and Panadura substations of Ceylon Electricity Board on the perspective of Electrical safety.</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-info"
                                                                data-bs-dismiss="modal">Close</button>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>






                                        </div>







                                    </div>

                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="image1 mt-4">
                                            <img width="1024" height="1024" src="<?php echo get_template_directory_uri(); ?>/./inc/service-img/SUBSTATION_569x319.jpg" alt=""
                                                loading="lazy">
                                        </div>


                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--  Substation Design end -->



                        <!--  Power Generation Plant Designs start -->
                        <div class="row mobspace">
                            <div class="heading-body">
                                <div class="row ">
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="image my-4">
                                            <img width="1024" height="1024" src="<?php echo get_template_directory_uri(); ?>/./inc/service-img/POWER_569x319.jpg" alt=""
                                                loading="lazy">
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="design-text-content mobmargin ">
                                            <h3 class="my-4">Power Generation Plant Designs</h3>

                                            <p class="design-para">Lorem ipsum dolor sit, amet consectetur adipisicing elit. </p>


                                            <!-- Button trigger modal -->
                                            <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                                data-bs-target="#modal5">
                                                More info...!
                                            </button>

                                            <!-- Modal -->
                                            <div class="modal fade" id="modal5" data-bs-backdrop="static"
                                                data-bs-keyboard="false" tabindex="-1"
                                                aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-scrollable modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title " id="staticBackdropLabel">
                                                                Power Generation Plant Designs</h5>
                                                            <button type="button" class="btn-close"
                                                                data-bs-dismiss="modal"
                                                                aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Feasibility study on 10MW Wind Power Plant in Island Delft.</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Design of the Proposed wind farm at Ambewela for ACE power – Transmission line design, earthing system design, Protection system design, interlocks etc.</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Consultancy Services for solar power systems implemented by Nikini Automations (Pvt) Ltd</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Consultancy services to Schneider Electric Sri Lanka For Second and Third phase of Senok Wind Farm at Puttalam on safety precautions to be taken during operation – Transformers and maintenance of transformers.</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-info"
                                                                data-bs-dismiss="modal">Close</button>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>



                                        </div>
                                        <!----Main content-->

                                    </div>

                                </div>
                            </div>

                        </div>
                        <!-- Power Generation Plant Designs end -->



                        <!--   Consultancy for Utility Regulatory Body start -->
                        <div class="row ">

                            <div class="heading-body1">
                                <div class="row revers-row flex-sm-row ">
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="design-text-content1 w">
                                            <h3 class="my-4"> Consultancy for Utility Regulatory Body</h3>

                                            <p class="design-para">Lorem ipsum dolor sit, amet consectetur adipisicing elit. </p>

                                            <!-- Button trigger modal -->
                                            <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                                data-bs-target="#modal6">
                                                More info...!
                                            </button>

                                            <!-- Modal -->
                                            <div class="modal fade" id="modal6" data-bs-backdrop="static"
                                                data-bs-keyboard="false" tabindex="-1"
                                                aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-scrollable modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="staticBackdropLabel">
                                                                Consultancy for Utility Regulatory Body</h5>
                                                            <button type="button" class="btn-close"
                                                                data-bs-dismiss="modal"
                                                                aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Defining safety index to Sri Lankan industrial sector for PUCSL.
                                                                        (Public Utility Commission Sri Lanka)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-info"
                                                                data-bs-dismiss="modal">Close</button>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>






                                        </div>







                                    </div>

                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="image1 mt-4">
                                            <img width="1024" height="1024" src="<?php echo get_template_directory_uri(); ?>/./inc/service-img/CONSULTANCY_569x319.jpg" alt=""
                                                loading="lazy">
                                        </div>


                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--   Consultancy for Utility Regulatory Body end -->


                        <!--   System Protection Designs start -->
                        <div class="row mobspace">
                            <div class="heading-body">
                                <div class="row ">
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="image my-4">
                                            <img width="1024" height="1024" src="<?php echo get_template_directory_uri(); ?>/./inc/service-img/SYSTEM_569x319.jpg" alt=""
                                                loading="lazy">
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="design-text-content">
                                            <h3 class="my-4"> System Protection Designs</h3>

                                            <p class="design-para">Lorem ipsum dolor sit, amet consectetur adipisicing elit. </p>


                                            <!-- Button trigger modal -->
                                            <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                                data-bs-target="#modal7">
                                                More info...!
                                            </button>

                                            <!-- Modal -->
                                            <div class="modal fade" id="modal7" data-bs-backdrop="static"
                                                data-bs-keyboard="false" tabindex="-1"
                                                aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-scrollable modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="staticBackdropLabel">
                                                                System Protection Designs</h5>
                                                            <button type="button" class="btn-close"
                                                                data-bs-dismiss="modal"
                                                                aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Havelock City – Phase II</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-info"
                                                                data-bs-dismiss="modal">Close</button>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>



                                        </div>
                                        <!----Main content-->

                                    </div>

                                </div>
                            </div>

                            <!--  System Protection Designs end -->













                        </div>
                        <!--  System Protection Designs end -->


                        <!--   Commercial Installations start -->
                        <div class="row">

                            <div class="heading-body1">
                                <div class="row revers-row flex-sm-row">
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="design-text-content1">
                                            <h3 class="my-4"> Commercial Installations</h3>

                                            <p class="design-para">Lorem ipsum dolor sit, amet consectetur adipisicing elit. </p>

                                            <!-- Button trigger modal -->
                                            <button type="button" class="btn btn-primary" data-bs-toggle="modal" class="design-btn"
                                                data-bs-target="#modal8">
                                                More info...!
                                            </button>

                                            <!-- Modal -->
                                            <div class="modal fade" id="modal8" data-bs-backdrop="static"
                                                data-bs-keyboard="false" tabindex="-1"
                                                aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-scrollable modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title " id="staticBackdropLabel">
                                                                Commercial Installations</h5>
                                                            <button type="button" class="btn-close"
                                                                data-bs-dismiss="modal"
                                                                aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Electrical Consultant of Access Tower 2</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Complete electrical design for Zam Gems Building Colombo 04.</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Complete electrical system design for Tower of Platinum. (Low Voltage and Medium Voltage)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Consultancy service for the First Solar Kiln in Sapugaskanda for Orient Lanka Trading.</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Design of generators for World Trade center (WTC) Sri Lanka.</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Design and installation of power distribution system at Onril (Pvt) Ltd- Katana.</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Electrical System Design for Metro Politain building – Dehiwala.
                                                                    </p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Electrical System Design for Havelock City Phase Two</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Electrical System Design for Auditor General’s Building – Baththaramulla</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Electrical System Design for Proposed Food court at Liberty plaza</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Conceptual design for the new project of Bambalapitiya Flats (2800 Luxury houses and 400 middle class houses) (Low Voltage and Medium Voltage)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Conceptual Electrical design for Keels City for Access Energy solutions (Pvt) Ltd.</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-info"
                                                                data-bs-dismiss="modal">Close</button>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>






                                        </div>







                                    </div>

                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="image1 mt-4">
                                            <img width="1024" height="1024" src="<?php echo get_template_directory_uri(); ?>/./inc/service-img/COMMERCIAL-resized.jpg" alt=""
                                                loading="lazy">
                                        </div>


                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--   Commercial Installations end -->


                        <!--   Industrial Sector Installation Designs start -->
                        <div class="row mobspace">
                            <div class="heading-body">
                                <div class="row ">
                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="image m-4">
                                            <img width="1024" height="1024" src="<?php echo get_template_directory_uri(); ?>/./inc/service-img/INDUSTRIAL_569x319.jpg" alt=""
                                                loading="lazy">
                                        </div>
                                    </div>

                                    <div class="col-lg-6 col-md-6 col-sm-12">
                                        <div class="design-text-content">
                                            <h3 class="my-4"> Industrial Sector Installation Designs</h3>

                                            <p class="design-para">Lorem ipsum dolor sit, amet consectetur adipisicing elit. </p>


                                            <!-- Button trigger modal -->
                                            <button type="button" class="btn btn-primary" data-bs-toggle="modal" class="design-btn"
                                                data-bs-target="#modal9">
                                                More info...!
                                            </button>

                                            <!-- Modal -->
                                            <div class="modal fade" id="modal9" data-bs-backdrop="static"
                                                data-bs-keyboard="false" tabindex="-1"
                                                aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-dialog-scrollable modal-lg">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title " id="staticBackdropLabel">
                                                                Industrial Sector Installation Designs</h5>
                                                            <button type="button" class="btn-close"
                                                                data-bs-dismiss="modal"
                                                                aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Local Electrical Consultant for Colombo Port City Project (2016)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>

                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Designing of the new electrical system for Link Natural Products (Pvt) Ltd, conducting of electrical safety audit to the existing factory and conducting of workshop on electrical safety and predictive and preventive maintenance to staff members of Link Natural Products (Pvt) Ltd.</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Complete design of J J Mills – Bangladesh for Energy Solve International.</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Successfully designed and constructed all the wiring modification and electrical protection systems of Aitken Spence printing (pvt) Ltd.</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Electrical Design, Safety Audit and Energy audit at Prima Ceylon Limited – Rajagiriya.</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Consultant for electrical expansions of Holcim Lanka. (Medium Voltage)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Consultant – Brandix Green Project.</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Electrical Distribution System design – Airport Garden Hotel New Phase</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Designer of the electrical distribution system for Ceylon Petroleum for the new expansion.</p>
                                                                </div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Evaluation of electrical safety of the total distribution system of the distribution system and proposal on relevant upgrades to meet standards BS 7671 (IEE Wiring regulation 17th edition), IEEE 80, IEC 62305, etc. at new Chilaw Substation of Ceylon Electricity Board- Dummalasooriya.</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Evaluation of electrical safety of the total distribution system of the distribution system and proposal on relevant upgrades to meet standards BS 7671 (IEE Wiring regulation 17th edition), IEEE 80, IEC 62305, etc. Project name – “Power system study on Sapugaskanda refinery”. Client – Resource management associates.</p>
                                                                </div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Electrical distribution review, Protection system design and review and proposal of electrical safety for underground substation.</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Successfully completed the installation work of the Creative Polymats (pvt) Ltd, Industrial estate, Dankotuwa.</p>
                                                                </div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>In Elastomatric (pvt) Ltd, Piliyandala, HT power panel, power transformer installation and HT cabling and termination task was completed together with our subcontractor BELA international.</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Electrical system design for Aeromatix Hotel – Pasikuda (Medium Rise)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Electrical system design for Pioneer Elastic Factory – Brandix India Apparel City, India Electrical system design for Proposed New Building for Ayurveda Hospital – Yakkala (Medium Rise)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>


                                                            <div class="row">
                                                                <div class="col-1"></div>
                                                                <div class="col-1">
                                                                     <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" fill="#42C8C4" class="bi bi-check-lg" viewBox="0 0 16 16">
                                                                        <path d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z"/>
                                                                      </svg>
                                                                </div>

                                                                <div class="col-9">
                                                                    <p>Electrical system design for Proposed New factory Building for CBL Foods International –Ranala Medium rise complex)</p>
                                                                </div>
                                                                <div class="col-1"></div>
                                                            </div>


                                                            
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-info"
                                                                data-bs-dismiss="modal">Close</button>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>



                                        </div>
                                        <!----Main content-->

                                    </div>

                                </div>
                            </div>

                            <!--  System Protection Designs end -->













                        </div>
                        <!--   Industrial Sector Installation Designs end -->





                    </div>
            </div>
        </div>



    </div>
    </section>
</div>
<!-- design category end -->
</div>


</div>
</div>
</div>
<!-- Body Content End-->

<?php
get_footer();
  ?>