<?php
/*
 * Template Name: Our Team
 
 */
?>
<?php
 get_header();

  ?>

   
  <!-- banner start -->
   
    <div class="banner-img " style="  background-image: url('<?php echo get_template_directory_uri(); ?>/./inc/img/banners-img/team-banner.png');">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
               <!-- <img src="./inc/img/slider2.jpg" alt=""> -->
            </div>
        </div>
       
    </div>
 
  <!-- banner end -->


  


      <!--  body content start -->
      <div class="body-content pb-5 pt-3 ">

<div class="container">
    <div class="row">
        
        <div class="col-lg-12">
            <div class="section" id="ourteam">

                <div class="section-header text-center">
                    <p class="h1 fw-bolder"> Our Team</p>
                </div>

                <!-- director row start -->
                <div class="row team-header text-center mt-5" >
                    <p class="h3 fw-bolder">Directors</p>
                </div>

                <div class="row directors-img mt-3 text-center">
                    <div class="col-lg-4 col-md-6 col-sm-12 directors-img-col mt-4">
                        <img src="<?php echo get_template_directory_uri(); ?>/./inc/img/team-img/dirfe.jpg" alt="" class="team-img">
                       <div class="team-name h5 mt-3 fw-bold">D. R. Fernando</div>
                       <div class="team-position mt-3 mb-5">Director</div>


                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 directors-img-col  mt-4">
                        <img src="<?php echo get_template_directory_uri(); ?>/./inc/img/team-img/dir.jpg" alt="" class="team-img">
                        <div class="team-name h5 mt-3 fw-bold">D. G. Rienzie Fernando</div>
                        <div class="team-position mt-3 ">Managing Director Chartered Engineer</div>
                        <div class="team-qulification mt-3 mb-5">B.Sc.Eng (Hons) – University of Moratuwa, C.Eng, MIESL</div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12 directors-img-col mt-4 ">
                        <img src="<?php echo get_template_directory_uri(); ?>/./inc/img/team-img/dirsenvi.jpg" alt="" class="team-img">
                        <div class="team-name h5 mt-3 fw-bold">N.A.A.U. Senevirathne</div>
                        <div class="team-position mt-3 mb-5 ">Director</div>
                    </div>
                </div>

                <!--------- dirctor row end -->


                 <!-- Executive Staff row start -->

                 <div class="row team-header text-center my-5" >
                    <p class="h3 fw-bolder">Executive Staff</p>
                </div>
                    

                <!-- row 1 start -->
                <div class="row Executive-img mt-3 text-center">
                    <div class="col-lg-4 col-md-6 col-sm-12 directors-img-col mt-4">
                        <img src="<?php echo get_template_directory_uri(); ?>/./inc/img/team-img/exkau (1).jpg" alt="" class="team-img">
                       <div class="team-name h5 mt-3 fw-bold">R. Kaushalya Alpitiarachchi</div>
                       <div class="team-position mt-3 ">General Manager/CEO</div>
                       <div class="team-qulification mt-3 ">Chartered Engineer B.Sc.Eng (Hons) – UoP, PG. Dip (Electrical Installations) – UoM, C.Eng, MIESL, MPMI, MGBCSL, Certified Thermographic Surveyor</div>
                  </div>


                    <div class="col-lg-4 col-md-6 col-sm-12 directors-img-col mt-4">
                        <img src="<?php echo get_template_directory_uri(); ?>/./inc/img/team-img/exlak.jpg" alt="" class="team-img">
                        <div class="team-name h5 mt-3 fw-bold">Laksith Uchitha Sirisena</div>
                        <div class="team-position mt-3 ">Engineering Manager</div>
                        <div class="team-qulification mt-3 ">Chartered Engineer B.Sc.Eng (Hons), MSc (Electrical Installations) – University of Moratuwa, C.Eng, MIESL, Cert.(HRM)</div>
                    </div>


                    <div class="col-lg-4 col-md-6 col-sm-12 directors-img-col mt-4 ">
                        <img src="<?php echo get_template_directory_uri(); ?>/./inc/img/team-img/excharith.jpg" alt="" class="team-img">
                        <div class="team-name h5 mt-3 fw-bold">B. A. Charith Sachintha</div>
                        <div class="team-position mt-3 ">HoD - Testing, Commissioning, Auditing & Servicing</div>
                        <div class="team-qulification mt-3 ">Lead Electrical Engineer B.Tech(EEE) – JNTU, MSc. (Electrical Installations) – University of Moratuwa [Reading], AMIE(SL)</div>
                    </div>
                </div>

                <!-- row 1 end -->


                
                <!-- row 2 start -->
                <div class="row Executive-img mt-3 text-center mt-5 ">
                    <div class="col-lg-4 col-md-6 col-sm-12 directors-img-col mt-4">
                        <img src="<?php echo get_template_directory_uri(); ?>/./inc/img/team-img/exhasitha.jpg" alt="" class="team-img">
                       <div class="team-name h5 mt-3 fw-bold">Hasitha Perera</div>
                       <div class="team-position mt-3 ">Electrical Engineer (Testing Division)</div>
                       <div class="team-qulification mt-3 ">B.Sc.Eng(Hons) – University of Moratuwa, AMIE(SL)</div>
                  </div>


                    <div class="col-lg-4 col-md-6 col-sm-12 directors-img-col mt-4">
                        <img src="<?php echo get_template_directory_uri(); ?>/./inc/img/team-img/exsajana.jpeg" alt="" class="team-img">
                        <div class="team-name h5 mt-3 fw-bold">Sajana Gunasekara</div>
                        <div class="team-position mt-3 ">Electrical Engineer (Design Division)</div>
                        <div class="team-qulification mt-3 ">B.Sc.Eng(Hons) – University of Moratuwa, AMIE(SL)</div>
                    </div>


                    <div class="col-lg-4 col-md-6 col-sm-12 directors-img-col mt-4">
                        <img src="<?php echo get_template_directory_uri(); ?>/./inc/img/team-img/exsudha.jpeg" alt="" class="team-img">
                        <div class="team-name h5 mt-3 fw-bold">Sudharaka Perera</div>
                        <div class="team-position mt-3 ">Electrical Engineer (Design Division)</div>
                        <div class="team-qulification mt-3 ">B.Sc.Eng(Hons) – University of Moratuwa, AMIE(SL)</div>
                    </div>
                </div>

                <!-- row 2 end -->


                
                <!-- row 3 start -->
                <div class="row Executive-img mt-3 text-center mt-5">
                    <div class="col-lg-4 col-md-6 col-sm-12 directors-img-col mt-4">
                        <img src="<?php echo get_template_directory_uri(); ?>/./inc/img/team-img/exsuwithi.jpg" alt="" class="team-img">
                       <div class="team-name h5 mt-3 fw-bold">Suwithi Karunasekara</div>
                       <div class="team-position mt-3 ">Electrical Engineer (Design Division)</div>
                       <div class="team-qulification mt-3 mb-5 ">B.Sc.Eng(Hons) – KDU Sri Lanka</div>
                  </div>


                    <div class="col-lg-4 col-md-6 col-sm-12 directors-img-col mt-4">
                        <img src="<?php echo get_template_directory_uri(); ?>/./inc/img/team-img/exharitha.jpg" alt="" class="team-img">
                        <div class="team-name h5 mt-3 fw-bold">Haritha Kalubowila</div>
                        <div class="team-position mt-3 ">Electrical Engineer (Testing Division)</div>
                        <div class="team-qulification mt-3 mb-5 ">B.Sc.Eng(Hons) – KDU Sri Lanka</div>
                    </div>


                    <div class="col-lg-4 col-md-6 col-sm-12 directors-img-col  mt-4 ">
                        <img src="<?php echo get_template_directory_uri(); ?>/./inc/img/team-img/exachala.jpg" alt="" class="team-img">
                        <div class="team-name h5 mt-3 fw-bold">Achala Kumarawadu</div>
                        <div class="team-position mt-3 ">Assistant Electrical Engineer (Testing Division)</div>
                        <div class="team-qulification mt-3 mb-5 ">B. Eng (Hons) - SLIIT</div>
                    </div>
                </div>

                <!-- row 3 end -->

     <!-- Executive Staff row end -->



     
                <!-- Administrative  row start -->
                <div class="row team-header text-center mt-5 mb-5" >
                    <p class="h3 fw-bolder">Administrative Staff</p>
                </div>

                <div class="row directors-img mt-3 text-center">
                    <div class="col-lg-6 col-md-6 col-sm-12 directors-img-col mt-4">
                        <img src="<?php echo get_template_directory_uri(); ?>/./inc/img/team-img/adgirl.jpg" alt="" class="team-img">
                       <div class="team-name h5 mt-3 fw-bold">Ayesha Silva</div>
                       <div class="team-position mt-3 mb-5">Director</div>


                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 directors-img-col mt-4">
                        <img src="<?php echo get_template_directory_uri(); ?>/./inc/img/team-img/adgirl.jpg" alt="" class="team-img">
                        <div class="team-name h5 mt-3 fw-bold">Dilini </div>
                        <div class="team-position mt-3 ">Managing Director Chartered Engineer</div>
                      
                    </div>
                  
                </div>

                <!--------- Administrative row end -->


            </div>
        </div>
        
    </div>
</div>
</div>



<?php
get_footer();
  ?>
  