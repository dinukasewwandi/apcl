<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package apcl-wordpress
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	  <!-- Required meta tags -->
	  <meta charset="utf-8">
  

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <!-- Font Awesome CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">

    <!-- Owl Carosel -->
       <!-- Owl Carosel -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.carousel.min.css">
    <link rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/assets/owl.theme.default.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js"></script>

    <!-- Custom CSS -->
    <link rel="stylesheet" href="inc/css/style.css">
      <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/style.css">
    <link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/inc/css/responsive.css">

    <title>APCL</title>

	<?php wp_head(); ?>
</head>






<body>
	

<!-- Header Start-->
   <!-- Header Start-->
    <div class="container-fluid">
        <div class="row">
            <!-- <div class="col-sm-12 col-md-12 col-lg-4 col-xl-3">
                <div class="logo" style="display: flex;">
                    <img class="img-fluid" src="inc/img/navlogo.png" alt="">
                    <span> <h4 class="mt-3"><b>Amithi Power <br> Consultants (PVT)Ltd</h4></b> </span>
                   

                </div>
            </div> -->


            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12">
                <div class="row header-top">
                    <div class="col-sm-4">
                        <div class="logo" style="display: flex;">
                            <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>/inc/img/navlogo.png" alt="">
                            <span> <h4 class="mt-3"><b>Amithi Power <br> Consultants (PVT)Ltd</h4></b> </span>
                           
                            <span class="year ml-2">Est. 2004</span>
                        </div>
                        
                    </div>
                    <div class="col-sm-8">
                        <span class="header-top-right">
                            <a class="header-mail" href="mailto:info@apl.lk">info@apl.lk</a>
                        </span>

                    </div>
                </div>


                <div class="row menu">
                    <nav class="navbar navbar-expand-lg ">
                        <div class="container-fluid">
                            <button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse"
                                data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
                                aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>
                            <div class="collapse navbar-collapse" id="navbarNav">
                                 <ul class="navbar-nav ms-auto">
                                    <li class="nav-item">
                                        <a class="nav-link" aria-current="page" href="https://yogeemedia.xyz/websites/apcl-new/home/">Home</a>
                                    </li>
                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" href="https://yogeemedia.xyz/websites/apcl-new/about-us/"
                                            id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown"
                                            aria-expanded="false">
                                            About Us
                                        </a>
                                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                            <li><a class="dropdown-item" href="https://yogeemedia.xyz/websites/apcl-new/about-us/"> About Us</a></li>
                                            <li><a class="dropdown-item" href="https://yogeemedia.xyz/websites/apcl-new/quality-policy/">Quality Policy</a>
                                            </li>
                                            <li><a class="dropdown-item" href="https://yogeemedia.xyz/websites/apcl-new/our-team/">Our Team</a></li>
                                        </ul>
                                    </li>

                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" href="https://yogeemedia.xyz/websites/apcl-new/services/"
                                            id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown"
                                            aria-expanded="false">
                                            Services
                                        </a>
                                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">

                                            <li><a class="dropdown-item" href="https://yogeemedia.xyz/websites/apcl-new/services/">Design,Modelling &
                                                    Simulations</a>
                                            </li>
                                            <li><a class="dropdown-item" href="https://yogeemedia.xyz/websites/apcl-new/testing-and-commissioning/">Testing &
                                                    Commissioning</a></li>
                                            <li><a class="dropdown-item" href="https://yogeemedia.xyz/websites/apcl-new/electrical-safety-audits/">Electrical Safety
                                                    Audits</a></li>
                                            <li><a class="dropdown-item" href="#">Project Management</a></li>
                                            <li><a class="dropdown-item" href="#">Turnkey Projects</a></li>
                                            <li><a class="dropdown-item" href="https://yogeemedia.xyz/websites/apcl-new/products/">Test Equipment Hiring</a>
                                            </li>
                                        </ul>
                                    </li>

                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink"
                                            role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                            Projects
                                        </a>
                                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                                            <li><a class="dropdown-item" href="https://yogeemedia.xyz/websites/apcl-new/design-projects/">Design Projects</a>
                                            </li>
                                            <li><a class="dropdown-item" href="https://yogeemedia.xyz/websites/apcl-new/testing-project/">Testing
                                                    Projects</a></li>
                                        </ul>
                                    </li>

                                    <li class="nav-item">
                                        <a class="nav-link" href="https://yogeemedia.xyz/websites/apcl-new/training/">Training</a>
                                    </li>

                                    <li class="nav-item">
                                        <a class="nav-link" href="https://yogeemedia.xyz/websites/apcl-new/news/">News</a>
                                    </li>

                                    <li class="nav-item">
                                        <a class="nav-link" href="https://yogeemedia.xyz/websites/apcl-new/resources/">Resources</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link" href="https://yogeemedia.xyz/websites/apcl-new/contact-us/">Contact Us</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    <!-- Header End -->
    <!-- Header End -->

