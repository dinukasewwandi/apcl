<?php
/*
 * Template Name: Testing Project
 
 */
?>
<?php
 get_header();

  ?>


<!-- banner start -->
   
    <div class="banner-img " style="  background-image: url('<?php echo get_template_directory_uri(); ?>/./inc/img/banners-img/testingprojects-banner.png');">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
               <!-- <img src="./inc/img/slider2.jpg" alt=""> -->
            </div>
        </div>
       
    </div>
 
  <!-- banner end -->
 

<!-- Body Content Start-->

    <div class="body-content  pt-3 ">

        <div class="container">
            <div class="row">

                <div class="col-12">
                    <div class="section" id="design">

                        <div class="section-header text-center ">
                            <p class="h1 fw-bolder">TESTING PROJECTS</p>


                        </div>



                    </div>


                    <!-- design category Start -->
                    <div class="design-categories">
                        <section class="service-design">
                            <div class="container-fluid">


                                <!--  Electrical Safety Audits -->
                                <div class="row  ">


                                    <div class="heading-body">
                                        <div class="row ">
                                            <div class="col-lg-6 col-md-6 col-sm-12">
                                                <div class="image ">
                                                    <img width="1024" height="1024"
                                                        src="<?php echo get_template_directory_uri(); ?>/./inc/service-img/LIGHTNING_569x319.jpg" alt=""
                                                        loading="lazy">
                                                </div>
                                            </div>

                                            <div class="col-lg-6 col-md-6 col-sm-12">
                                                <div class="design-text-content">
                                                    <h3 class="my-4 "> Electrical Safety Audits​</h3>

                                               


                                                    <!-- Button trigger modal -->
                                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                                        class="design-btn" data-bs-target="#modal1">
                                                        More info...!
                                                    </button>




                                                    <!-- Modal -->
                                                    <div class="modal fade" id="modal1" data-bs-backdrop="static"
                                                        data-bs-keyboard="false" tabindex="-1"
                                                        aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                        <div class="modal-dialog modal-dialog-scrollable modal-lg">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title " id="staticBackdropLabel ">
                                                                        Electrical Safety Audits</h5>


                                                                    <button type="button" class="btn-close"
                                                                        data-bs-dismiss="modal"
                                                                        aria-label="Close"></button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Comprehensive Electrical Safety Audit and
                                                                                Workshop for <b>CBL Foods International
                                                                                    (Pvt) Limited, Ranala</b> </p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg></i>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Carrying out of Safety audit and
                                                                                Awareness program on Electrical safety
                                                                                at <b>Packages Lanka (Pvt) Ltd </b> </p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg></i>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Service providers for Hayleys Fiber Group
                                                                                of Companies including electrical
                                                                                maintenance and safety and energy audits
                                                                            </p>
                                                                        </div>
                                                                        <div class="col-1"></div>

                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Conducting safety audits, safety awareness programs and issuing of compliance report to IEE wiring regulation 17th edition for five star Hotels</p>
                                                                            <div class="row">
                                                                                <div class="col-2">
                                                                                    <div class="new-icon">
                                                                                        <i
                                                                                            class="fa-solid fa-circle-half-stroke list-circle"></i>
                                                                                    </div>
                                                                                </div>

                                                                                <div class="col-10">
                                                                                    <p class="sub-list-content">Aitken Spence group</p>
                                                                                </div>
                                                                            </div>

                                                                            <div class="row">
                                                                                <div class="col-2">
                                                                                    <div class="new-icon">
                                                                                        <i
                                                                                            class="fa-solid fa-circle-half-stroke list-circle"></i>
                                                                                    </div>
                                                                                </div>

                                                                                <div class="col-10">
                                                                                    <p class="sub-list-content">Cinnamon Group</p>
                                                                                </div>
                                                                            </div>


                                                                            <div class="row">
                                                                                <div class="col-2">
                                                                                    <div class="new-icon">
                                                                                        <i
                                                                                            class="fa-solid fa-circle-half-stroke list-circle"></i>
                                                                                    </div>
                                                                                </div>

                                                                                <div class="col-10">
                                                                                    <p class="sub-list-content">
                                                                                        Taj Group</p>
                                                                                </div>
                                                                            </div>


                                                                            <div class="row">
                                                                                <div class="col-2">
                                                                                    <div class="new-icon">
                                                                                        <i
                                                                                            class="fa-solid fa-circle-half-stroke list-circle"></i>
                                                                                    </div>
                                                                                </div>

                                                                                <div class="col-10">
                                                                                    <p class="sub-list-content">Hilton, Jungle Beach</p>
                                                                                </div>
                                                                            </div>


                                                                            <div class="row">
                                                                                <div class="col-2">
                                                                                    <div class="new-icon">
                                                                                        <i
                                                                                            class="fa-solid fa-circle-half-stroke list-circle"></i>
                                                                                    </div>
                                                                                </div>

                                                                                <div class="col-10">
                                                                                    <p class="sub-list-content">Uga bay</p>
                                                                                </div>
                                                                            </div>


                                                                            <div class="row">
                                                                                <div class="col-2">
                                                                                    <div class="new-icon">
                                                                                        <i
                                                                                            class="fa-solid fa-circle-half-stroke list-circle"></i>
                                                                                    </div>
                                                                                </div>

                                                                                <div class="col-10">
                                                                                    <p class="sub-list-content">
                                                                                        Ulagalla Resort </p>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>


                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Successfully completed the safety and energy audit, and modification of electrical distribution system and installation of suitable protection system at <b>Hay Mat (pvt) Ltd), Galle</b>  </p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Safety and energy audit and modification of the installation at <b>747 Hanger, Sri Lankan Air Lines, Bandaranayake International Airport</b> </p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                 

                                                                  
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-info"
                                                                        data-bs-dismiss="modal">Close</button>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>



                                                </div>








                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Electrical Safety Audits end -->




                                <!--  Thermography Survey -->
                                <div class="row  ">

                                    <div class="heading-body1">
                                        <div class="row revers-row flex-sm-row">
                                            <div class="col-lg-6 col-md-6 col-sm-12">
                                                <div class="design-text-content1">
                                                    <h3 class="my-4">Thermography Survey</h3>

                                                    <p class="design-para">Introduced Thermal Imaging of Electrical Installations to Sri Lankan industry and carrying out thermal imaging audits successfully. </p>

                                                    <!-- Button trigger modal -->
                                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                                        data-bs-target="#modal2">
                                                        More info...!
                                                    </button>

                                                    <!-- Modal -->
                                                    <div class="modal fade" id="modal2" data-bs-backdrop="static"
                                                        data-bs-keyboard="false" tabindex="-1"
                                                        aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                        <div class="modal-dialog modal-dialog-scrollable modal-lg">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title " id="staticBackdropLabel ">
                                                                        Thermography Survey</h5>
                                                                    <button type="button" class="btn-close"
                                                                        data-bs-dismiss="modal"
                                                                        aria-label="Close"></button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>CEB Substation Panadura & New Chilaw</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Ceylon Tobacco Company – Colombo, Kandy & all depots</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Standard Chartered Head Office & Branches</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Unilever Head office, Colombo</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Iceland Business Center, Colombo</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Asia Power Station, Sapugaskanda</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Iceland Residencies, Colombo</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Agio Tobacco Processing, Biyagama</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>GSK, Aththidiya</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Unilever tea factory (CT) at Thalawakele</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Ceylon Biscuits Ltd</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    
                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Taj Samudra Hotels</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                      
                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>HSBC Global Resourcing</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Ansel Lanka</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>


                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Holcim Lanka</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Cinnamon Hotels</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Hilton – Colombo</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Aitken Spence Hotels</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>


                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Aitken Spence Printing</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    
                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Print care group</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                        
                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Noratel International</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>ICC Hotels</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Havelock City</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>World Trade Centre</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>


                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Bodyline (Pvt) Ltd – Horana (MAS Group)</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>


                                                                    

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Brandix Casual Wear – Seeduwa</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    
                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Omega Line (Pvt) Ltd – Makandura</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                              
                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>FDK Lanka (Pvt) Ltd – Katunayake</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                             
                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Michelangelo Footwear Limited – Katunayake</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Bio mass plant, Tokyo cement- China Bay</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Hirdramani group of companies</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Monarch Residencies</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>





                                                                </div>
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-info"
                                                                        data-bs-dismiss="modal">Close</button>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>






                                                </div>







                                            </div>

                                            <div class="col-lg-6 col-md-6 col-sm-12">
                                                <div class="image1 mt-4">
                                                    <img width="1024" height="1024"
                                                        src="<?php echo get_template_directory_uri(); ?>/./inc/service-img/TRANSMISSION_569x319.jpg" alt=""
                                                        loading="lazy">
                                                </div>


                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Thermography Survey end -->




                                <!--  Medium Voltage Testing  Services -->
                                <div class="row mobspace ">
                                    <div class="heading-body">
                                        <div class="row  ">
                                            <div class="col-lg-6 col-md-6 col-sm-12">
                                                <div class="image mt-4">
                                                    <img width="1024" height="1024"
                                                        src="<?php echo get_template_directory_uri(); ?>/./inc/service-img/EARTHING_569x319.jpg" alt=""
                                                        loading="lazy">
                                                </div>
                                            </div>

                                            <div class="col-lg-6 col-md-6 col-sm-12">
                                                <div class="design-text-content ">
                                                    <h3 class="my-4"> Medium Voltage Testing Services</h3>

                                                   


                                                    <!-- Button trigger modal -->
                                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                                        data-bs-target="#modal3">
                                                        More info...!
                                                    </button>

                                                    <!-- Modal -->
                                                    <div class="modal fade" id="modal3" data-bs-backdrop="static"
                                                        data-bs-keyboard="false" tabindex="-1"
                                                        aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                                        <div class="modal-dialog modal-dialog-scrollable modal-lg">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title " id="staticBackdropLabel ">
                                                                        Medium Voltage Testing Services</h5>
                                                                    <button type="button" class="btn-close"
                                                                        data-bs-dismiss="modal"
                                                                        aria-label="Close"></button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>VPower Emergency Power Plant – Horana (2019)</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>VPower Emergency Power Plant – Hambantota (2019)</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>HV Protection Relays – ACE Power, Embilipitiya</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Commissioning of 33 kV Protection Relays of 1MW Solar Installation at Brandix, Batticaloe</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Commissioning of Protection relays – Kotmale Dam, Kotmale</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>MV Testing & Commissioning – RIU Hotel, Ahungalla (2016)</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Testing and commissioning of the Havelock city Phase I (Low Voltage and Medium Voltage)</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Commissioning of Unilever Ceylon Factory, Horana.</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Transformer and Relay Testing – Unilever Sri Lanka</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Transformer and Relay Testing – CTC Colombo factory & Kandy factory</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>

                                                                    <div class="row">
                                                                        <div class="col-1"></div>
                                                                        <div class="col-1">
                                                                            <svg xmlns="http://www.w3.org/2000/svg"
                                                                                width="15" height="15" fill="#42C8C4"
                                                                                class="bi bi-check-lg"
                                                                                viewBox="0 0 16 16">
                                                                                <path
                                                                                    d="M12.736 3.97a.733.733 0 0 1 1.047 0c.286.289.29.756.01 1.05L7.88 12.01a.733.733 0 0 1-1.065.02L3.217 8.384a.757.757 0 0 1 0-1.06.733.733 0 0 1 1.047 0l3.052 3.093 5.4-6.425a.247.247 0 0 1 .02-.022Z" />
                                                                            </svg>
                                                                        </div>

                                                                        <div class="col-9">
                                                                            <p>Transformer and Relay Testing – Havelock City Project</p>
                                                                        </div>
                                                                        <div class="col-1"></div>
                                                                    </div>


                                                                   
                                                               
                                                                <div class="modal-footer">
                                                                    <button type="button" class="btn btn-info"
                                                                        data-bs-dismiss="modal">Close</button>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>



                                                </div>
                                                <!----Main content-->

                                            </div>

                                        </div>
                                    </div>

                                </div>
                                <!--  Medium Voltage Testing  Services end -->







                            </div>
                    </div>
                </div>



            </div>
            </section>
        </div>
        <!-- design category end -->
    </div>


    </div>
    </div>
    </div>
    <!-- Body Content End-->
<?php
get_footer();
  ?>