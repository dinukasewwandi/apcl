<?php
/*
 * Template Name: About Us
 
 */
?>
<?php
 get_header();

  ?>
<!-- banner start -->
   
    <div class="banner-img " style="  background-image: url('<?php echo get_template_directory_uri(); ?>/./inc/img/banners-img/aboutus-banner.png');">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
               <!-- <img src="./inc/img/slider2.jpg" alt=""> -->
            </div>
        </div>
       
    </div>
 
  <!-- banner end -->
  
    <!-- about section 1  -->
    <div class="section" id="absec-1">
        <div class="container">
            <div class="absec-1-heading text-center pb-3">
                <h2 class="ab-heading py-3">CEO Message</h2>
                <span class="pt-4">"We are header-mail for the best solutions for your electrical & power engireening
                    needs"</span>
            </div>
            <div class="absec-1-content pt-5">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-6">
                        <div class="img-sec">
                            <img class="img-fluid img-1" src="<?php echo get_template_directory_uri(); ?>//inc/img/absec-img1.jpg" alt="">
                            <img class="img-fluid img-2" src="<?php echo get_template_directory_uri(); ?>//inc/img/absec-img2.jpg" alt="">
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-12 col-lg-6">
                        <div class="content-sec">
                            <div class="wc-content px-3 py-3">
                                <!-- <h1 class="header">why <span class="blue">choose us</span></h1> -->
                                <div class="wc-list">
                                    <ul>
                                        <li>Chartered Electrical Engineer with over 36 years experience in Power Transmission and Distribution Sector.</li>
                                        <li>Serving many Local & Foreign bodies and private institutions as an electrical and energy consultant.</li>
                                        <li> Has been in major Power sector technical evaluation committees in the Island.</li>
                                        <li>Recognized as the specialist in Medium and high voltage distribution designs by
                                            local and international professionals.</li>
                                        <li>Lorem ipsum dolor sit amet consectetur adipisicing elit.</li>
                                       
                                    </ul>
                                    <p>Eng. Rienzie is conducting lectures for M.Sc in Electrical Installation at University of Moratuwa and CPD program at IESL (Institution of Engineers Sri Lanka)</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- about section 2  -->
    <div class="section bg-blue" id="absec-2">
        <div class="container">
            <div class="text-center">
                <h2 class="ab-heading py3">
                    Brief About Company
                </h2>
                <p class="absec-2-content">
                    <p><b>Amithi Power Consultants Pvt. Ltd</b>&nbsp;is a Sri Lanka based Electrical Engineering consulting company established in <b>2004</b> providing <b>Design Consultancy (Electrical Power &amp; MEP), Testing, Commissioning, Auditing &amp; Servicing</b> of Electrical Installations for both local &amp; international parties. We also provide design and consultancy services for building services engineering projects. APCL maintains a close relationship with the clients and has become a renowned company in Sri Lanka.<br><br><span style="color: var( --e-global-color-text ); font-family: var( --e-global-typography-text-font-family ), Sans-serif; font-weight: var( --e-global-typography-text-font-weight );">We strive to deliver high quality services in a timely manner which incorporates fullest attention to detail and compliance standards.</span><br></p>
                </p>
            </div>
        </div>
    </div>


    <!-- about vision mission sec -->
    <div class="section" id="vm-sec">
        <div class="container">
            <div class="row">
                <div class="col-sm-6 col-md-6 col-lg-6">
                    <div class="vm-content text-center">
                        <div class="vm-img">
                            <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>//inc/img/sample.png" alt="">
                        </div>
                        <div class="vm-title">
                            <h1>Vision</h1>
                        </div>
                        <div class="vm-caption">
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Architecto nihil modi illo
                                voluptas
                                vitae quibusdam iure omnis obcaecati ratione, in facilis sapiente nobis tenetur officiis
                                facere consectetur numquam delectus sint?</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-6 col-lg-6">
                    <div class="vm-content text-center">
                        <div class="vm-img">
                            <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>//inc/img/sample.png" alt="">
                        </div>
                        <div class="vm-title">
                            <h1>Mission</h1>
                        </div>
                        <div class="vm-caption">
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Architecto nihil modi illo
                                voluptas
                                vitae quibusdam iure omnis obcaecati ratione, in facilis sapiente nobis tenetur officiis
                                facere consectetur numquam delectus sint?</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <!-- Message section -->
    <div class="section" id="msg">
        <div class="container">
            <table class="msg-table">
                <tr class="tr-1">
                    <td class="cap-td">
                        <h1 class="pb-3">Quality</h1>
                        <p>Our Quality Management System (QMS) implemented to deliver customer services is certified to comply with ISO 9001 : 2015 by DAS Certification Body (accredited by UKAS – United Kingdom Accreditation Service).

                            All works are quality controlled by Senior Engineers and Consulting Chartered Engineers to provide accurate & reliable service to customers.</p>
                    </td>
                    <td class="img-td">
                        <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>//inc/img/absec-img2.jpg" alt="">
                    </td>
                </tr>

                <tr class="tr-2">
                    <td class="img-td">
                        <img class="img-fluid engadge-img" src="<?php echo get_template_directory_uri(); ?>//inc/img/absec-img2.jpg" alt="">
                    </td>
                    <td class="cap-td">
                        <h1 class="pb-3">Engaged</h1>
                        <p>Direct involvement of professional expertise during all the works carried out by us, which makes us prominent, in the field of Electrical and Building Services Engineering.</p>
                    </td>

                </tr>

                <tr class="tr-1">
                    <td class="cap-td">
                        <h1 class="pb-3">Expertise</h1>
                        <p>Our  professional team consists of 3 Chartered Engineers registered with IESL (Institution of Engineers Sri Lanka), Managing Director (Veteran Senior Consultant), CEO/GM (Consultant) & Engineering Manager (Consultant).

                            All Engineers are qualified and majority are registered associate members of IESL who are currently following MSc and other CPD programs.  >> Meet our Team</p>
                    </td>
                    <td class="img-td">
                        <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>//inc/img/absec-img2.jpg" alt="">
                    </td>
                </tr>
            </table>
        </div>
    </div>


    <!-- View more banner section -->
    <!-- <div class="section" id="vmore">
        <div class="container text-center">
            <h2 class="vmore_text pb-4">
                Lorem ipsum dolor sit amet consectetur adipisicing elit,
            </h2>
            <a class="btn btn-light" href="about.html">View More</a>
        </div>
    </div> -->


    <!-- map section -->
    <div class="section" id="map">
        <div class="container">
            <img class="img-fluid" src="<?php echo get_template_directory_uri(); ?>//inc/img/map.png" alt="">
        </div>
    </div>


    <!-- Body Content End-->
    <!-- Body Content End-->

<?php
get_footer();
  ?>
  