<?php
/*
 * Template Name: Contact Us
 
 */
?>
<?php
 get_header();

  ?>


  <!-- banner start -->
   
    <div class="banner-img " style="  background-image: url('<?php echo get_template_directory_uri(); ?>/./inc/img/banners-img/contactus-banner.png');">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12">
               <!-- <img src="./inc/img/slider2.jpg" alt=""> -->
            </div>
        </div>
       
    </div>
 
  <!-- banner end -->

<div class="ash-header">
        <div class="container ash-container pb-3 pt-4">
            <div class="row">
                <div class="col-lg-1 col-md-1"></div>
                <div class="col-lg-10 col-md-10 col-sm-12">
                    <h4>Contact Us</h4>
                </div>

                <div class="col-lg-1 col-md-1"></div>
            </div>
        </div>
    </div>

</div>
    <div class="container">
        <div class="row">
            <div class="col-lg-1 col-md-1"></div>
            <div class="col-lg-10 col-md-10 col-sm-12">
                <section class="my-5" >
                 <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12">
                        <div class="row">
                            <div class="col-lg-8 col-md-8 col-sm-12">
                                <div class="row">
                                    <div class="col-lg-3 col-md-3 col-sm-6">
                                        <p>ADDRESS</p>
                                        <p>1080/9, Atigala Mawatha, Rajagiriya, Sri Lanka</p>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-6">
                                        <p>EMAIL</p>
                                        <p>info@apcl.lk</p>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-6">
                                        <p>PHONE</p>
                                        <p> <b>Office</b> <br>
                                            (+94) 112 875 278 <br> <br>
                                            
                                          <b>Hotline</b>  <br>
                                            (+94) 777 809 844
                                            (+94) 715 173 425</p>
                                    </div>
                                    <div class="col-lg-3 col-md-3 col-sm-6">
                                        <p>VISIT US</p>
                                        <p>Live Location</p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-12"></div>
                        </div>
                    </div>
                 </div>

                </section>
            </div>
            <div class="col-lg-1 col-md-1"></div>
        </div>
    </div>
  
<?php
get_footer();
  ?>
  