<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package apcl-wordpress
 */

?>

<div class="footer">
        <div class="footer-top" style="background-image: url(<?php echo get_template_directory_uri(); ?>/inc/img/footer-img.jpg) ;">
            <div class="container footer-sec">
                <div class="footer-menu text-center pt-4 pb-3">
                    <table width="100%">
                        <tr>
                            <td><a href="">Home</a></td>
                            <td><a href="">About Us</a></td>
                            <td><a href="">Our Team</a></td>
                            <td><a href="">Services</a></td>
                            <td><a href="">Project</a></td>
                            <td><a href="">Training</a></td>
                            <td><a href="">Resources</a></td>
                            <td><a href="">Contact Us</a></td>
                        </tr>
                    </table>
                </div>
                <div class="footer-contact">
                    <table>
                        <tr>
                            <td class="mob-break">
                                <table>
                                    <tr>
                                        <td class="icon">
                                            <div class="border">
                                                <i class="fa fa-map-marker" aria-hidden="true"></i>
                                            </div>
                                        </td>
                                        <td class="details">
                                            <span>1080/9, Atigala Mawatha, <br>Rajagiriya,<br> Sri Lanka</span>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                            <td class="mob-break">
                                <table>
                                    <tr>
                                        <td class="icon">
                                            <div class="border">
                                                <i class="fa fa-phone" aria-hidden="true"></i>
                                            </div>
                                        </td>
                                        <td class="details">
                                            <span><a href="tel:+94112875278">(+94) 112 875 278</a></span>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                            <td class="mob-break">
                                <table>
                                    <tr>
                                        <td class="icon">
                                            <div class="border">
                                                <i class="fa fa-envelope" aria-hidden="true"></i>
                                            </div>
                                        </td>
                                        <td class="details">
                                            <span><a href="mailto:info@apcl.lk">info@apcl.lk</a></span>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
        <div class="footer-bottom text-center py-3">
            <div class="container">
                <span>@ Copyright
                    <script>document.write(new Date().getFullYear())</script> by RI Construction | Website by <a
                        target="_blank" href="https://yogeemedia.com/">YogeeMedia</a>
                </span>
            </div>
        </div>
    </div>

		<!-- Default scripts -->		
		<script type="text/javascript" src="http://code.jquery.com/jquery-1.9.1.min.js"></script><!-- google: latest jquery CDN -->
		<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/inc_files/scripts/ui.js"></script>
		
		<!-- 3rd party plugins -->
		<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/inc_files/scripts/animate/modernizr-2.8.1.min.js"></script>
		<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/inc_files/scripts/animate/wow.min.js"></script>
		<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/inc_files/scripts/animate/animateScroll.js"></script>
		
		<!--lightslider script -->
		<script type="text/javascript" src="<?php echo get_template_directory_uri(); ?>/inc_files/scripts/lightslider/src/js/lightslider.js"></script>
		<script type="text/javascript">new WOW().init();</script>
		<script>
      function initMap() {

        var map = new google.maps.Map(document.getElementById('map-section'), {
          zoom: 16,
          center: new google.maps.LatLng(6.9225065, 79.9750624),
          mapTypeId: 'roadmap'
        });
      	var image = "<?php echo get_template_directory_uri(); ?>/inc_files/images/map-logo.png";
        var marker = new google.maps.Marker({
          position: new google.maps.LatLng(6.9225065, 79.9750624),
      		title:"Hello World!",
          map: map,
      		icon: image
        });
      }
    </script>

		
    <script async defer
    src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDIrUvCzgx6KP5W3M7Bt0wlbuynrbwkKSY&callback=initMap">
    </script>


<!-- Custom JavaScript -->
 <!-- Custom JavaScript -->
    <script src="<?php echo get_template_directory_uri(); ?>/inc/js/script.js"></script>
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
        crossorigin="anonymous"></script>
		<?php wp_footer(); ?>
	</body>
</html>

